function showallhidden()
{
  document.getElementById("hidden").id="washidden";
}

function hideallhidden()
{
  document.getElementById("washidden").id="hidden";
}

function showloading()
{
  document.getElementById("loading").id="showloading"; 
}