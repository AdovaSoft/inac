function printpage()
{
  window.print();
  window.close();
}