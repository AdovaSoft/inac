<?php
       $date1=$_GET['date1'];
       $date2=$_GET['date2'];
	   if($date1&&$date2)
	   echo "<h3>Report from ".$inp->dateconvert($date1)." to ".$inp->dateconvert($date2)."</h3>";
?>