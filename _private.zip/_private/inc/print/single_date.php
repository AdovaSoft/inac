<?php
       $date=$_GET['date'];
	   echo "<h3>Report of ".$inp->dateconvert($date)."</h3>";
?>