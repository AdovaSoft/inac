<?php
  if($inp->value_pgd('s'))
  {
    $det_query = sprintf("SELECT name,post,sallary,date FROM staff LEFT JOIN staff_joning USING(idstaff) WHERE idstaff = %d;",$inp->value_pgd('s'));        
    $bon_query = sprintf("SELECT id,date,month,year,ammount*-1 FROM (SELECT * FROM staff_bonus WHERE idstaff = %d) as staff LEFT JOIN transaction USING(id);",$inp->value_pgd('s'));
	$staf_det = $qur ->getCustomizedSelectQuery($det_query, 4);
    $staf_bon = $qur ->getCustomizedSelectQuery($bon_query, 5);
	        echo "<h2 class='blue'>".strtoupper($staf_det[0][0])."</h2>";
            echo "Post : ".$staf_det[0][1];
            echo "<br/>Sallary : ".$staf_det[0][2];
			echo "<br/>Joining date : ".$inp->dateconvert($staf_det[0][3]);
            
            if(COUNT($staf_bon)<=0){
                echo "<h3 class='blue'>No bonus record stored yet</h3>";
            }
            else{
                echo "<h3 class='blue'>Bonus report</h3>";
				echo "<table align='center' class='rb'>";
                echo "<tr><td>Paying date</td><td>Bonus of</td><td>Ammount</td></tr>";
                $bon_total=0;
                $n = COUNT($staf_bon);
                for($i=0; $i<$n; $i++){
                    
                    echo "<tr>";
                        echo "<td>";
                            echo $inp->dateconvert($staf_bon[$i][1]);
                        echo "</td>";
                        
                        echo "<td>";
                            echo $inp->printMonth($staf_bon[$i][2]).' '.$staf_bon[$i][3];
                        echo "</td>";
                        
                        echo "<td>";
                            echo $staf_bon[$i][4];
							$bon_total=$bon_total+$staf_bon[$i][4];
                        echo "</td>";
                        
                    echo "</tr>";
                    
                }
				echo "<tr><td colspan = 3>Total : $bon_total</td></tr>";
                echo "</table>";
            }  
  }
?>