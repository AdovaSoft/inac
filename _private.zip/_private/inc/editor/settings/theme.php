<?php
  if($_POST['change'])
  {
    if($_POST['newcss']>0)
    {
      $qur = new indQuary();
      $change=$qur->changecss($idstaff, $_POST['newcss']);
      if($change)
      {
        $extrastring="&&say=1";
      }
      else
      {
        $extrastring="&&say=2";
      }      
    }
    else
    {
      $extrastring="&&say=3";
    } 
  }
  else
  {
    $extrastring="&&say=2";
  }
?>