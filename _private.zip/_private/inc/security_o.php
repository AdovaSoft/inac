<?php
  if($_POST['e']||$_GET['e'])
  {  
    $encptid=$_POST['e'];
	if(!$encptid)
	  $encptid=$_GET['e'];
    $pass=$_SESSION["user".$encptid."pass"];
    $username=$_SESSION["user".$encptid."username"];
    include("_private/db/login_db_fn.php");
    $checking=login_check_session($username,$pass);
    if($checking!=0)
    {    
      $idstaff=$_SESSION["user".$encptid."idstaff"];
      include("_private/db/_db_func.php");
      $qur = new indQuary();
      $inp = new html();
    }
    else
    {
      header("Location:index.php");
    }
  }
  else
  {
    header("Location:index.php");
  }
?>