<?php
  if($page && $sub)
  {
    $section=$section."/".$page;
    $page=$sub;
  }

  if($page)
  {
    $path="_private/inc/".$section."/".$page.".php";
    if(file_exists("$path"))
    {
      include("$path");
    }
    else
    {
      include("_private/inc/contents/default.php");
    }
  }
  else
  {
    include("_private/inc/".$section."/home.php");
  }
?>