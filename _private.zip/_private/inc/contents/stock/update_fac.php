<h2>Update Factory Stock </h2>
<?php
         include("_private/inc/usercheck.php");
         if($inp->value_pgd('say')==1)
		 {
		    $custom_message="<br/><h3 class='green'>Stock Update Successfull</h3>";
		 }
		 elseif($inp->value_pgd('say')==2)
		 {
		    $custom_message="<br/><h3 class='red'>Stock Update failed</h3>";
		 }
		 elseif($inp->value_pgd('say')==3)
		 {
           $c_s = $qur->getCondRow('stock', array('stock'), 'idproduct', '=', $inp->value_pgd('p'));
		   $custom_message="<br/><h3 class='red'>Current stock : ".$c_s[0][0]."<br/>You cant remove ".$_POST['s']."</h3>"."<br/><h3 class='red'>Exedding your stock</h3>";
		 }
		 elseif($inp->value_pgd('say')==4)
		 {
		    $custom_message="<br/><h3 class='red'>DATA ARE NOT VALID</h3>";
		 }
		 elseif($inp->value_pgd('say')==5)
		 {
		    $custom_message="<br/><h3 class='red'>Stock update cant be zero or negetive</h3>";
		 }
		 else
		 {
		    $custom_message="<br/><h3 class='blue'>Please provide update informaton</h3>";
		 }
		 
		echo $custom_message;
        echo "<br/><form action='editor.php' method = 'POST' class='embossed'>";
            echo "<img src='images/blank1by1.gif' width='300px' height='1px'/><br/>";
			echo "<br/>Date : ";
            $inp->input_date('d', date('Y-m-d'));
            echo "<br/><br/>Product : ";
            $array = $qur->getCustomizedSelectQuery('SELECT * FROM product LEFT JOIN stock USING(idproduct);', 3);
            $qur->getDropDownRowArray($array, 0, 1, 'p', null);
            echo "<br/><br/>";
            
            $inp->input_text('Quentity : ', 's',$inp->value_pgd('s'));
            
            echo "<br/>";
            $inp->input_raido('Add', 'pr', 1, 0);
            $inp->input_raido('Remove', 'pr', -1, 0);
            echo "<br/>";
            echo "<input type='hidden' name='editor' value='stock/update_fac'/>";
            echo "<input type='hidden' name='e' value='".$encptid."'/>";
            echo "<input type='hidden' name='returnlink' value='index.php?page=stock&&sub=update_fac&&e=".$encptid."'/>";
            $inp->input_submit('ab','Update');
        echo "</form>";
?>
