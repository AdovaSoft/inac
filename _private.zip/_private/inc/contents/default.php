<?php
  echo "<h1>Sorry there is no info about ".$page."</h1><br/>";
  include ("_private/inc/contents/home.php");
?>