<h1>Settings</h1>
<div id="bigmenu">
  <a href="index.php?e=<?php echo $encptid?>&&page=settings&&sub=theme">Change Theme</a>
  <a href="index.php?e=<?php echo $encptid?>&&page=settings&&sub=pass">Change Password</a>
</div>