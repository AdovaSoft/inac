<h1>Delete Currrent User</h1>
<br/>
<?php      
    include("_private/inc/usercheck.php");
    if(isset($_POST['ab'])){
        if(isset($_POST['s']) && $_POST['s'] != null){
            $qur = new indQuary();
            $query = sprintf("DELETE FROM user WHERE idstaff = %d",$_POST['s']);
            $qur->excQuery('START TRANSACTION');
            $flag = $qur->excQuery($query);
            
            if($flag){
                $custommessage="<h3 class='green'>User Successfully Deleted</h3><br/>";
                $qur->excQuery('COMMIT');
            }
            else{
                $custommessage="<h3 class='red'>Failed to Delete</h3><br/>";
                $qur->excQuery('ROLLBACK');
            }
        }
    }
	else{
	  $custommessage="<h3 class='blue'>Please Select a staff to delete from user</h3><br/>";
	}
    echo "<form method = 'POST' class='embossed'>";
			echo $custommessage;	
            echo "<img src='images/blank1by1.gif' width='300px' height='1px'/><br/>";
			$get_user = $qur->getCustomizedSelectQuery("SELECT idstaff,name FROM user LEFT JOIN staff USING(idstaff) WHERE type = 0;", 2);
            $qur->getDropDownRowArray($get_user, 0, 1, 's', null);
			echo "<br/>";
            $inp->input_submit('ab', 'DELETE');
    echo "</form>";
?>
