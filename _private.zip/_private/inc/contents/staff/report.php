<h1>Staff Report</h1>
<br/>
<?php   
            $res = $qur ->getCondRow('staff', array('idstaff','name','post'), 'status', '=', 1);
            echo "<form method = 'POST' class='embossed'>";
			echo "<h3 class='blue'>Select  staff</h3><br/>";	
            echo "<img src='images/blank1by1.gif' width='300px' height='1px'/><br/>";
            echo "<select name = 's' >";
                echo "<option></option>";
                if($inp->value_pgd('s')){
                    foreach($res as $r){
                        if($r[0]==$inp->value_pgd('s'))
                            echo "<option value = '".$r[0]."' selected > $r[1] ($r[2]) </option>";
                        else
                            echo "<option value = '".$r[0]."' > $r[1] ($r[2]) </option>";      
                    }
                }
                else{
                    foreach($res as $r){
                        echo "<option value = '".$r[0]."' > $r[1] ($r[2]) </option>";
                    }
                }
            echo "</select>";
            echo "<br/><br/><input type = 'submit' name = 'ab' value = 'Show' />";
            echo "</form>";
    
	    
	
        if($inp->value_pgd('s') != null){
            $det_query = sprintf("SELECT name,post,sallary,date,hour FROM staff LEFT JOIN staff_joning USING(idstaff) WHERE idstaff = %d;",$inp->value_pgd('s'));
            $sal_query = sprintf("SELECT id,date,sal_month,sal_year,ammount*-1 FROM (SELECT * FROM staff_sallary WHERE idstaff = %d) as staff LEFT JOIN transaction USING(id) ORDER BY  sal_year, sal_month;",$inp->value_pgd('s'));
            $bon_query = sprintf("SELECT id,date,month,year,ammount*-1 FROM (SELECT * FROM staff_bonus WHERE idstaff = %d) as staff LEFT JOIN transaction USING(id);",$inp->value_pgd('s'));
            $rep_query = sprintf("SELECT rep_month, rep_year, attended, rep_leave, absent, overtime, sallary, hour FROM staff_report s WHERE idstaff = %d ORDER BY rep_year, rep_month;",$inp->value_pgd('s'));
            
			if(($_POST['delete']=="Delete")&&($usertype==1))
			{
			   $delete=$qur->delete_attendense($_POST['s'], $_POST['m'], $_POST['y']);
			   if($delete)
			     echo "<br/><h3 class='green'>Attendence entry Deleted</h3>";
			   else
			     echo "<br/><h3 class='red'>Could not delete attendence entry</h3>";
			}
			
			if(isset($_POST['at_update'])&&($usertype==1)){
               $mon = $_POST['r_m'];
               $yer = $_POST['r_y'];
                if(isset($_POST['s'])){
                  $emp[0] = $_POST['s'];
                  $at[0] = $_POST['s_at'];
                  $lv[0] = $_POST['s_lv'];
                  $ab[0] = $_POST['s_ab'];
                  $ov[0] = $_POST['s_ov'];
                }
        
               $flag = $qur->InsAllAttendence($mon,$yer,$emp,$at,$lv,$ab,$ov,1);
      
               if($flag){
                  echo "<br/><h3 class='green'>Attendance Update Successfull</h3>";
               }
               else{
                    echo "<br/><h3 class='red'>Attendance Update failed</h3>";    
               }  
            }
 
			if(isset($_POST['save_sal'])&&($usertype==1)){
				$date = $_POST['d_y'].'-'.$_POST['d_m'].'-'.$_POST['d_d'];				
				if(isset($_POST['s']) && $_POST['s'] != null && isset($_POST['amnt']) && $_POST['amnt'] > 0 && isset($_POST['tt']) && $_POST['tt'] > 0  ){
					$flag = true;
					if($_POST['tt'] == 2){
						$flag = $qur->addBonusPay($date, $_POST['s'], $_POST['m'], $_POST['y'], $_POST['amnt'], $_POST['cmnt'].' as Bonus');
					}
					elseif($_POST['tt'] == 1){
						$flag = $qur->addSallaryPay($date, $_POST['s'], $_POST['m'], $_POST['y'], $_POST['amnt'], $_POST['cmnt'].' as Salary');
					}
					if($flag){
						echo "<br/><h3 class='green'>Salary Update Successfull</h3>";
					}
					else{
						echo "<br/><h3 class='red'>Salary Update failed</h3>";
					}
				}
				else{
					echo "<br/><h3 class='red'>Please provide all info</h3>";
				}
			}
			
			
            $staf_det = $qur ->getCustomizedSelectQuery($det_query, 5);
            $staf_sal = $qur ->getCustomizedSelectQuery($sal_query, 5);
            $staf_bon = $qur ->getCustomizedSelectQuery($bon_query, 5);
            $staf_rep = $qur ->getCustomizedSelectQuery($rep_query, 8);
            
            echo "<br/><h2 class='blue'>".strtoupper($staf_det[0][0])."</h2>";
            echo "<br/>Post : ".$staf_det[0][1];
            echo "<br/>Sallary : ".$staf_det[0][2];
            echo "<br/>Duty Hours : ".$staf_det[0][4];
			echo "<br/>Joining date : ".$inp->dateconvert($staf_det[0][3]);
            if(COUNT($staf_rep)<=0){
                echo "<br/><h3 class='blue'>No attendece record stored yet</h3>";
            }
            else{
                echo "<br/><h3 class='blue'>Attendence and Earned Salary report</h3>";
			    echo "<br/><a href='print.php?e=".$encptid."&&&&page=staff&&sub=attendance&&s=".$inp->value_pgd('s')."' class='button' target='_blank'><b> Print Attendenceand Earned Salary Report</b></a><br/>";
                echo "<table align='center' class='rb'>";
                echo "<tr>";
                echo "<td>Month</td><td>Attended</td><td>Leave</td><td>Absent</td><td>Overtime</td><td>Salary</td><td>Duty<br/>Hours</td><td>Earned Salary</td>";
				if($usertype==1)
				{
				  echo "<td>Action</td>";
				}
				echo "</tr>";
                foreach($staf_rep as $s){
                    echo "<tr>";
					
                        echo "<td>";
                            echo $inp->printMonth($s[0])." ".$s[1];
                        echo "</td>";
						
                        echo "<td>";
                            echo $s[2];
                        echo "</td>";
                        
                        echo "<td>";
                            echo $s[3];
                        echo "</td>";
                        
                        echo "<td>";
                            echo $s[4];
                        echo "</td>";
                        
                        echo "<td>";
                            echo $s[5];
                        echo "</td>";
						
                        echo "<td>";
                            echo $s[6];
                        echo "</td>";
						
                        echo "<td>";
                            echo $s[7];
                        echo "</td>";
						
                        echo "<td>";
                            echo sprintf("%.2f",$s[6]*($s[2]+$s[3]+($s[5])/$s[7])/$inp->printMonthDays($s[0],$s[1]));
                        echo "</td>";
						/*
						  
						*/
						
						if($usertype==1)
						{
                          echo "<td>";
						    echo "<br/><form method='POST'>";
							   echo "<input type='hidden' name='m' value='".$s[0]."'/>";
							   echo "<input type='hidden' name='y' value='".$s[1]."'/>";
							   echo "<input type='hidden' name='s' value='".$inp->value_pgd('s')."'/>";
							   echo "<input type='submit' name='delete' value='Delete'/>";
							echo "</form>";
                          echo "</td>";
						}
						
                    echo "</tr>";
                }
                echo "</table>";
            }
			
			  if($usertype==1)
			  {
              echo "<br/><form class='embossed' method='POST'>";
                            echo "Attendence For : ";
                            $d = date('Y-m-d');
                            $y = $d[0].$d[1].$d[2].$d[3];
                            $m = $d[5].$d[6];
                            $inp->select_month('r_m',$m);
                            echo " of ";
                            $inp->select_digit('r_y', 2011, 2021, $y , 1);
                            echo "<table align='center' class='centeraligned'>";
                                echo "<tr>";
                                    echo "<th>Attended</th>";
                                    echo "<th>Leave</th>";
                                    echo "<th>Absent</th>";
                                    echo "<th>Overtime</th>";
                                echo "</tr>";
                                echo "<tr>";
                          
                                echo '<td>';
								   echo "<input type = 'hidden' name = 's' value ='".$inp->value_pgd('s')."' />";
                                    if(isset($_POST['s_at']))
                                        $inp->select_digit('s_at', 0, 31, $_POST['s_at'], 1);
                                    else
                                        $inp->select_digit('s_at', 0, 31, 0, 1);
                                echo '</td>';
                                
                                echo '<td>';
                                    if(isset($_POST['s_lv']))
                                        $inp->select_digit('s_lv', 0, 31, $_POST['s_lv'], 1);
                                    else
                                        $inp->select_digit('s_lv', 0, 31, 0, 1);
                                echo '</td>';
                                
                                echo '<td>';
                                    if(isset($_POST['s_ab']))
                                        $inp->select_digit('s_ab', 0, 31, $_POST['s_ab'], 1);
                                    else
                                        $inp->select_digit('s_ab', 0, 31, null, 1);
                                echo '</td>';
                                
                                echo '<td>';
                                    if(isset($_POST['s_ov']))
                                        $inp->select_digit('s_ov', 0, 372, $_POST['s_ov'], 1);
                                    else
                                        $inp->select_digit('s_ov', 0, 372, 0, 1);
                                echo '</td>';
                                echo "</tr>";
                          
                            echo "</table>";
							echo "<br/><input type='submit' name='at_update' value='Update Attendance'>";
              echo "</form>";
			  }
			  
            if(COUNT($staf_sal)<=0){
                echo "<br/><h3 class='blue'>No sallary record stored yet</h3>";
            }
            else{
                echo "<br/><br/><h3 class='blue'>Sallary report</h3>";
			    echo "<br/><a href='print.php?e=".$encptid."&&&&page=staff&&sub=salary&&s=".$inp->value_pgd('s')."' class='button' target='_blank'><b> Print Salary Report</b></a><br/>";
                echo "<table align='center' class='rb'>";
                echo "<tr><td>Paying date</td><td>Sallary of</td><td>Ammount</td></tr>";
                $n = COUNT($staf_sal);
                $amnt = 0;
                $samnt;
                for($i=0; $i<$n; $i++){
                    $samnt += $staf_sal[$i][4];
                    echo "<tr>";
                        echo "<td>";
                            echo $inp->dateconvert($staf_sal[$i][1]);
                        echo "</td>";
                        
                        echo "<td>";
                            echo $inp->printMonth($staf_sal[$i][2]).' '.$staf_sal[$i][3];
                        echo "</td>";
                        
                        echo "<td>";
                            echo $staf_sal[$i][4];
                        echo "</td>";
                        
                    echo "</tr>";
                }
                echo "<tr><td colspan = 3>Total : $samnt</td></tr>";
                echo "</table>";
            }
            
            if(COUNT($staf_bon)<=0){
                echo "<br/><h3 class='blue'>No bonus record stored yet</h3>";
            }
            else{
                echo "<br/><br/><h3 class='blue'>Bonus report</h3>";
			    echo "<br/><a href='print.php?e=".$encptid."&&&&page=staff&&sub=bonus&&s=".$inp->value_pgd('s')."' class='button' target='_blank'><b> Print Bonus Report</b></a><br/>";
                echo "<table align='center' class='rb'>";
                echo "<tr><td>Paying date</td><td>Bonus of</td><td>Ammount</td></tr>";
                $bon_total=0;
                $n = COUNT($staf_bon);
                for($i=0; $i<$n; $i++){
                    
                    echo "<tr>";
                        echo "<td>";
                            echo $inp->dateconvert($staf_bon[$i][1]);
                        echo "</td>";
                        
                        echo "<td>";
                            echo $inp->printMonth($staf_bon[$i][2]).' '.$staf_bon[$i][3];
                        echo "</td>";
                        
                        echo "<td>";
                            echo $staf_bon[$i][4];
							$bon_total=$bon_total+$staf_bon[$i][4];
                        echo "</td>";
                        
                    echo "</tr>";
                    
                }
				echo "<tr><td colspan = 3>Total : $bon_total</td></tr>";
                echo "</table>";
            }
			
			if($usertype==1)
			{
				        echo "<br/><form method = 'POST'   class='embossed'>"; 
                        echo "<h3>Pay Salary or bonus</h3><br/>";
						echo "Date : ";
						$inp->input_date('d', Date('Y-m-d'));
						echo "<br/><br/>";
						echo "<input type='hidden' name='s' value='".$inp->value_pgd('s')."'>";
						echo "Month : ";
						$inp->select_month('m',isset($_POST['m']) ? $_POST['m'] : Date('m') );
						$inp->select_digit('y', 2000, 2050, isset($_POST['y']) ? $_POST['y'] : Date('Y')  , 1);
        
						echo "<br/><br/>Ammount :<br/>";
						echo "<input type='text' name='amnt'/>";
						echo "<select name='tt'>";
						echo "<option >  </option> ";
						echo "<option value = '1'> Sallary </option> ";
						echo "<option value = '2'> Bonus </option> ";
						echo "</select>";
						echo "<input type = 'hidden' name = 'cmnt'  value = 'Paying to ".strtoupper($staf_det[0][0])." (".$staf_det[0][1].")' />";
						echo "<br/>";
						$inp->input_submit('save_sal', 'Save');
						echo "</form>";
			}
        }
?>