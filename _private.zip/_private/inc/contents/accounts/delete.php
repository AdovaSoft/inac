<?php
    if(isset($_POST['delete']) && ($_POST['delete']='Delete') && isset($_POST['tid']) && ($usertype==1))
	{
	   $del=$qur->deleteTransaction($_POST['tid']);
	   if($del)
	     echo "<h3 class='green'>Transaction Deleted Successfully</h3><br/>";
	   else
	     echo "<h3 class='red'>Could not Delete Reansaction</h3><br/>";
	}
	
	if($usertype!=1&&isset($_POST['delete']))
    {
  	    echo "<h2 class='red'>You are not permited to Delete.</h2><br/>";
    }
?>