<a href="index.php?e=<?php echo $encptid?>">Home</a>
<a href="index.php?e=<?php echo $encptid?>&&page=sells">Sells</a>
<a href="index.php?e=<?php echo $encptid?>&&page=purchase">Purchase</a>
<a href="index.php?e=<?php echo $encptid?>&&page=stock">Stock</a>
<a href="index.php?e=<?php echo $encptid?>&&page=accounts">Accounts</a>
<a href="index.php?e=<?php echo $encptid?>&&page=staff">Staff</a>
<a href="index.php?e=<?php echo $encptid?>&&page=party">Party</a>
<?php
  echo "<a href='logout.php?e=".$encptid."'>Logout</a>";
?>
<br/><small>This Database is developed by,<a href="http://adovasoft.com/" target="_blank">Adova Soft</a></small>