<?php
    if($usertype!=1)
	{
	  echo "<h1 class='red'>You are not permited to use this page.</h1></center></body></div></center></body></html>";
	  die();
	}
?>