<?php
  $username=htmlentities($_POST['username']);
  $userpass=htmlentities($_POST['userpass']);
  
  if($_GET['e'])
  {  
    $encptid=$_GET['e'];
    $pass=$_SESSION["user".$encptid."pass"];
    $username=$_SESSION["user".$encptid."username"];
    include("_private/db/login_db_fn.php");
    $checking=login_check_session($username,$pass);
    if($checking!=0)
    {  
      $checkingdata=mysql_fetch_array($checking);
      $csschoice=$checkingdata[0];  
      $idstaff=$_SESSION["user".$encptid."idstaff"];
      $usertype=$_SESSION["user".$encptid."usertype"];  
      include("_private/db/_db_func.php");
      $inp = new html();
      $qur = new indQuary();
    }
    else
    {
      $loginmessage="<h2 class='blue'>Please Login.</h2>";
      include("_private/inc/loginform.php");
    }
  }
  elseif(isset($username) && isset($userpass) && isset($_POST['submit']))
  {
    include("_private/db/login_db_fn.php");
    $checking=login_check($username,$_POST['userpass']);
    if($checking!=0)
    { 
      $checkingdata = mysql_fetch_array($checking);
      $idstaff = $checkingdata[0];
      $pass = $checkingdata[1];
      $usertype = $checkingdata[2];
      $csschoice = $checkingdata[3];
      $username = $_POST['username'];

      $encptid=md5($idstaff);
        
      $_SESSION["user".$encptid."idstaff"]=$idstaff;
      $_SESSION["user".$encptid."pass"]=$pass;
      $_SESSION["user".$encptid."usertype"]=$usertype;
      $_SESSION["user".$encptid."username"]=$username;
     
      include("_private/db/_db_func.php");
      $inp = new html();
      $qur = new indQuary();
    }
    else
    {
      $loginmessage="<h2 class='red'>Wrong ID or Password.</h2>";
      include("_private/inc/loginform.php");
    }
  }
  elseif((!isset($username) || !isset($userpass)) && isset($_POST['submit']))
  {
     $loginmessage="<h2 class='red'>Please fill all fields.</h2>";
     include("_private/inc/loginform.php");
  }  
  elseif($_GET['logout'])
  {
     $loginmessage="<h2 class='green'>Loged out successfully.</h2>";
     include("_private/inc/loginform.php");
  }
  else
  {
     $loginmessage="<h2 class='blue'>Please login.</h2>";
     include("_private/inc/loginform.php");
  }
?>