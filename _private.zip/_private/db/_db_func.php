<?php
        class html{
			public function extrastring($name){
			               $value=$this->value_pgd($name);
						   if($value!=null)
						   {
						      $extention="&&".$name."=".$value;
						   }
						   else
						   {
						     $extention="";
						   }
						   return $extention;
			}
		
			public function value_pgd($name,$default_value=null){
				 if(isset($_POST[$name]))
				 {
				    return $_POST[$name];
				 }
				 elseif(isset($_GET[$name]))
				 {
				    return $_GET[$name];
				 }
				 elseif($default_value!=null)
				 {
				   return $default_value;
				 }
				 else
				 {
				    return null;
				 }
            }
            
            public function input_text($label, $name, $value, $class=null, $id=null ){
                echo $label. " <input type='text' step='any' name = '".$name."' value = '".$value."' class = '".$class."' id = '".$id."' /> <br/>";
            }
                        
            public function input_hidden($name, $value ){
                echo  " <input type = 'hidden' name = '".$name."' value = '".$value."' />";
            }
            
            public function printMonth($i){
                
                    if($i == 1 || $i == '01'){
                        echo "January";
                    }
                    else if ($i == 2 || $i == '02'){
                        echo "February";
                    }
                    else if ($i == 3 || $i == '03'){
                        echo "March";
                    }
                    else if ($i == 4 || $i == '04'){
                        echo "April";
                    }
                    else if ($i == 5 || $i == '05'){
                        echo "May";
                    }
                    else if ($i == 6 || $i == '06'){
                        echo "June";
                    }
                    else if ($i == 7 || $i == '07'){
                        echo "July";
                    }
                    else if ($i == 8 || $i == '08'){
                        echo "August";
                    }
                    else if ($i == 9 || $i == '09'){
                        echo "September";
                    }
                    else if ($i==10){
                        echo "October";
                    }
                    else if ($i==11){
                        echo "November";
                    }
                    else if ($i==12){
                        echo "December";
                    }
            }
			
			
            public function printMonthDays($m,$y)
			{
			   if(($m==4)||($m==6)||($m==9)||($m==11))
			   {
			      return 30;
			   }
			   elseif(($m==1)||($m==3)||($m==5)||($m==7)||($m==8)||($m==10)||($m==12))
			   {
			      return 31;			      
			   }
			   elseif($m==2){
			      if(($y%4)==0)
				  {
				     return 29;
				  }
				  else
				  {
				     return 28;
				  }
			   }
			   else
			   {
			      return null;
			   }
			}
            
            public function input_submit($name,  $value){
                echo "<br/> "." <input type = 'submit' name = '".$name."' value = '".$value."' /> <br/>";
            }
            
            public function select_month($name, $sel){
                echo "<select name = '".$name."' >";
                for($i=1; $i<=12; $i++){
                    if($i == $sel)
                        echo "<option selected value = '".$i."' >";
                    else{
                        echo "<option value = '".$i."' >";
                    }
                    if($i=='01'){
                        echo "Jan </option>";
                    }
                    else if ($i=='02'){
                        echo "Feb </option>";
                    }
                    else if ($i=='03'){
                        echo "Mar </option>";
                    }
                    else if ($i=='04'){
                        echo "Apr </option>";
                    }
                    else if ($i=='05'){
                        echo "May </option>";
                    }
                    else if ($i=='06'){
                        echo "Jun </option>";
                    }
                    else if ($i=='07'){
                        echo "Jul </option>";
                    }
                    else if ($i=='08'){
                        echo "Aug </option>";
                    }
                    else if ($i=='09'){
                        echo "Sep </option>";
                    }
                    else if ($i==10){
                        echo "Oct </option>";
                    }
                    else if ($i==11){
                        echo "Nov </option>";
                    }
                    else if ($i==12){
                        echo "Dec </option>";
                    }
                }
                echo "</select>";
            }
            
            public function input_raido($label, $name, $value, $sel){
                if($sel == 1)
                    echo " <input type = 'radio' name = '".$name."' value = '".$value."' checked /> ".$label ;
                else
                    echo " <input type = 'radio' name = '".$name."' value = '".$value."'/> ".$label ;
            }
            
            public function input_select($label, $name, $value, $sel){
                if($sel)
                    echo " <input type = 'checkbox' name = '".$name."' value = '".$value."' checked /> ".$label ;
                else
                    echo " <input type = 'checkbox' name = '".$name."' value = '".$value."'/> ".$label ;
            }
            
            public function check($label, $a){
                if(isset($_POST['a']) && $_POST[$a] != null){
                    return true;
                }
                if(isset($label))
                    echo $label . " is missing <br/>";
                return false;
            }
            
            public function isPositive($label, $a){
                if($_POST[$a] > 0){
                    return true;
                }
                echo $label."<br/>";
                return false;
            }
            
            public function getPostDate($p){
			    if($_POST[$p.'_y']&&$_POST[$p.'_m']&&$_POST[$p.'_d'])
                  return $_POST[$p.'_y'].'-'.$_POST[$p.'_m'].'-'.$_POST[$p.'_d'];    
				else 
				   return 0;
            }
            
            public function select_digit($name, $from , $to, $sel, $int){
                echo "<select name = '".$name."' > ";
                for($i=$from; $i<=$to; $i = $i + $int){
                    if($sel==$i)
                        echo "<option selected>".$i."</option>";
                    else
                        echo "<option >".$i."</option>";
                }
                echo "</select>";
            }

            public function input_date($n, $t){
                
                $y = $t[0].$t[1].$t[2].$t[3];
                $m = $t[5].$t[6];
                $d = intval($t[8].$t[9]);
                
				$yless=date(Y)-10;
				$ymore=date(Y)+10;
				
                $this->select_digit($n.'_d', 1, 31, $d,1);
                $this->select_digit($n.'_m', 1, 12, $m,1);
                $this->select_digit($n.'_y', $yless, $ymore, $y,1);
            }

            public function dateconvert($date){
				if($date=="0000-00-00"||(!$date))
					return "";
				elseif($date==date("Y-m-d"))
					return "Today";
				else
					return $newDate = date("d M Y (D)", strtotime($date));
			}

            public function dateValid($t){
                $y = $t[0].$t[1].$t[2].$t[3];
                $m = $t[5].$t[6];
                $d = intval($t[8].$t[9]);
				return checkdate($m,$d,$y);
			}			

		}
        
        class inserter{
            private $tableName = null;
            private $colums = array();
            private $values = array();
            private $flag = array();
            
            public function setParameeter($par_id, $value){
                switch($par_id){
                    CASE 1: 
                        $this->tableName = $value;
                        break;
                    CASE 2: 
                        $this->colums = $value;
                        break;
                    CASE 3: 
                        $this->values = $value;
                        break;
                    CASE 4: 
                        $this->flag = $value;
                        break;
                    default :
                        echo "Action Failed!";   
                }
            }
            
            public function resetParameeter(){
                unset($this->colums);
                unset($this->flag);
                unset($this->values);
                unset($this->tableName);
            }
            public function Insert($sQ){
                return $sQ->InsQuery($this->tableName, $this->colums, $this->values, $this->flag);
            }
        }
        
        class query{
			private $srv_con;
			private $dtb_con;
			
			public function __construct($host = 'localhost', $user = 'websqflt_nasa',  $pass='70LEk!YX73PU' ,$db = 'websqflt_nas'){
				
				$srv_con = mysql_connect($host,$user,$pass);
			
				if($srv_con){
					$dtb_con = mysql_select_db($db,$srv_con);
					if($dtb_con){
						mysql_query("SET NAMES utf8");
					}
					else{
						echo "Failed!\n";
					}
				}
				else{
					echo "Failed!\n";
				}
				
			}
                        
                        
			public function genQuery($table, $col,$i){
				if($i == 0){
					return sprintf("SELECT %s%s",$col[$i], $this->genQuery($table, $col,$i+1));
				}
				else if($i < count($col) ){
					return sprintf(", %s %s",$col[$i],$this->genQuery($table, $col,$i+1));
				}
				else if(count($col)==$i){
					return sprintf( " FROM %s",$table);
				}
			}
		
			public function getRowAsc($table, $col, $order){
				$i = 0;
				$value;
				$query = sprintf("%s ORDER BY %s ASC",$this->genQuery($table, $col, 0),$order);
				$res = mysql_query($query);
				
				while($row = mysql_fetch_array($res)){
					for($j=0; $j<count($col); $j++){
						$value[$i][$j]= $row[$j];
					}
					$i++;
				}
				
				return $value;
			}

			public  function getRowDsc($table, $col, $order ){
			
				$i = 0;
				$value;
				$query = sprintf("%s ORDER BY %s DESC",$this->genQuery($table, $col, 0),$order);
				$res = mysql_query($query);
			
				while($row = mysql_fetch_array($res)){
					for($j=0; $j<count($col); $j++){
						$value[$i][$j]= $row[$j];
					}
					$i++;
				}
			
				return $value;
			}

			public  function getRowDscLimit($table, $col, $order,$ll,$ul ){

				$i = 0;
				
				$query = sprintf("%s ORDER BY %s DESC LIMIT %d, %d",$this->genQuery($table, $col, 0),$order,$ll,$ul);
				$res = mysql_query($query);
                                
                                $value[0][0] = 0;
				while($row = mysql_fetch_array($res)){
					for($j=0; $j<count($col); $j++){
						$value[$i][$j]= $row[$j];
					}
					$i++;
				}
                                
				return $value;
			}
		
			public  function getRow($table, $col){
				// Find every $col from $table
				
				$query = $this->genQuery($table, $col, 0);
				$i = 0;
				$value;
				$res = mysql_query($query);
				
				while($row = mysql_fetch_array($res)){
					for($j=0; $j<count($col); $j++){
						$value[$i][$j]= $row[$j];
					}
					$i++;
				}
				
				return $value;
			}
		
			
			public  function getCondRowLimited($table, $cols, $matchcol, $cond, $value , $llimit, $ulimit){
				
				$query = sprintf("%s WHERE %s %s %s LIMIT %d , %d",$this->genQuery($table, $cols, 0),$matchcol, $cond, $value,$llimit, $ulimit);
				$result;
				$i = 0;
				$n = count($cols);
			
				$res = mysql_query($query);
			
				while($row = mysql_fetch_array($res)){
					for($j=0; $j<$n; $j++){
						$result[$i][$j]= $row[$j];
					}
					$i++;
				}
				
				return $result;
			}	
		
	        public  function getCondRow($table, $cols, $matchcol, $cond, $value){
			
				$query = sprintf("%s WHERE %s %s %s",$this->genQuery($table, $cols, 0),$matchcol, $cond, $value);
				$result;
				$i = 0;
				$n = count($cols);
			
				$res = mysql_query($query);
			
				while($row = mysql_fetch_array($res)){
			
					for($j=0; $j<$n; $j++){
						$result[$i][$j]= $row[$j];
					}
					$i++;
				}
				
				return $result;
			}
		
		
			public  function genInsQuery($tab, $cols, $vals, $flags){
				$cols_are = "";
				$vals_are = "";
                        
				for ($i=0; $i<count($cols); $i++){
					if($i==0){
						$cols_are = sprintf("( %s",$cols[$i]);
					}
					else{
						$cols_are = sprintf(" %s , %s",$cols_are,$cols[$i]);
					}
				}
				$cols_are = sprintf(" %s ) ",$cols_are);
			
				for ($i=0; $i<count($vals); $i++){
					if($i==0){
						if($flags[$i]=='s'){
							$vals_are = sprintf("( '%s'",$vals[$i]);
						}
						else if($flags[$i]=='d'){
							$vals_are = sprintf("( %d",$vals[$i]);
						}
						else if ($flags[$i]=='f'){
							$vals_are = sprintf("( %f",$vals[$i]);
							}
					}
				
					else{
						if($flags[$i]=='s'){
							$vals_are = sprintf(" %s , '%s'",$vals_are,$vals[$i]);
						}
						else if($flags[$i]=='d'){
							$vals_are = sprintf(" %s , %d",$vals_are,$vals[$i]);
						}
						else if ($flags[$i]=='f'){
							$vals_are = sprintf(" %s , %f",$vals_are,$vals[$i]);
						}
					}
				}
                        
				$vals_are = sprintf(" %s ) ",$vals_are);
			
				return sprintf("INSERT %s %s VALUES %s",$tab, $cols_are,$vals_are);
			}

			public  function InsQuery($tab, $cols, $vals, $flags){
				$query = $this->genInsQuery($tab, $cols, $vals, $flags);
				if(mysql_query($query))
					return 1;
				else
					return 0;
			}
		
			public function getCustomizedSelectQuery($query, $n){
			
				$result = null;
				$i = 0;
                                
				$res = mysql_query($query);
                                
                if($res)
                {				
				  while($row = mysql_fetch_array($res)){
					for($j=0; $j < $n; $j++){
                                            if(isset($row[$j]))
						$result[$i][$j]= $row[$j];
					}
					$i++;
				  }
				}
				
				return $result;
			}

            public function excQuery($query){
				return mysql_query($query);
			}
			
			public function valueCount($table,$col,$val){
				$query = sprintf("SELECT COUNT(%s) FROM %s WHERE %s = %s",$col, $table, $col, $val);
				$v = $this->getCustomizedSelectQuery($query, 1);
				return $v[0][0];
			}
			
			public  function getDropDown($table, $column, $value, $name,$sel){
				$row = $this->getRow($table, array($column, $value));
				echo "<select name = '".$name."' >";
					echo "<option> </option>";
					for($i=0; $i<count($row); $i++){
						if($sel==$row[$i][1]){
							echo "<option value = '".$row[$i][1]."' selected>". $row[$i][0] . "</option>";
						}
						else{
							echo "<option value = '".$row[$i][1]."' >". $row[$i][0] . "</option>";
						}
					}
				echo "</select>";
			}
                        
                        
			public  function getAllCheckBox($table, $column, $value, $name){
				$row = $this->getRow($table, array($column, $value));
                                for($i=0; $i<count($row); $i++){
                                        echo "<input type= 'checkbox' name= $name$i value= '".$row[$i][1]."'  />". "&nbsp;&nbsp;". $row[$i][0] ;
				}
                                return count($row);
			}
			
			
			public function getColumnOfTable($table){
				$query = sprintf("DESC %s",$table);
				$res = $this->getCustomizedSelectQuery($query, 6);
				$final_res;
				
				for($i=0; $i<count($res); $i++){
					$final_res[$i] = $res[$i][0];
				}
				return $final_res;
			}
			
			public function genUpdQuery($table,$cols,$vals, $flag, $mat,$con,$m_val){
				$num = count($cols);
				$qur = sprintf("UPDATE %s SET",$table);
				
				for($i=0; $i<$num; $i++){
					if($flag[$i] == "s"){
						$qur = sprintf("%s %s = '%s'", $qur,$cols[$i],$vals[$i]);
					}
					else{
						$qur = sprintf("%s %s = %s", $qur,$cols[$i],$vals[$i]);
					}
					if($i != $num - 1){
						$qur = sprintf("%s \n,",$qur);
					}
				}
			
				return $qur = sprintf("%s WHERE %s %s %s",$qur,$mat,$con,$m_val);
			}
			
			public function updateColumn($table,$cols,$vals,$flag,$mat,$con,$val){
				$query = $this->genUpdQuery($table, $cols, $vals, $flag,$mat,$con,$val);
				if(mysql_query($query)){
					return 1;
				}
				else{
					return 0;
                }
			}
			
			public function getDropDownRowArray($ar,$ind_sho,$ind_val,$name,$sel){
                            
                            echo "<select name = '".$name."' >";
					echo "<option> </option>";
                                        $n = count($ar);
					for($i=0; $i<$n; $i++){
						if($sel == $ar[$i][$ind_sho]){
                                            echo "<option value = '".$ar[$i][$ind_sho]."' selected >". $ar[$i][$ind_val] . "</option>";
						}
						else{
							echo "<option value = '".$ar[$i][$ind_sho]."' >". $ar[$i][$ind_val] . "</option>";
						}
					}
				echo "</select>";
			}
			
			public function getDropDownRowPrArray($ar,$ind_sho,$pr_ind, $ind_val,$name,$sel){
				echo "<select name = '".$name."' >";
				echo "<option> </option>";
				for($i=0; $i<count($ar); $i++){
					if($sel==$ar[$i][$ind_val]){
						echo "<option value = '".$ar[$i][$ind_sho]."' selected>". $ar[$i][$ind_val] .' ( '.$ar[$i][$pr_ind]. ' ) '."</option>";
					}
					else{
						echo "<option value = '".$ar[$i][$ind_sho]."' >". $ar[$i][$ind_val] .' ( '.$ar[$i][$pr_ind]. ' ) '."</option>";
					}
				}
				echo "</select>";
			}
			
			public function columnDataType($table, $col){
				$type;
				$query = sprintf("DESC %s",$table);
				$res = $this->getCustomizedSelectQuery($query, 5);
				$i=0;
				$flag = 1;
				while($flag && $res[$i]){
					if($res[$i][0] == $col){
						$flag = 0;
						break;
					}
					$i++;
				}
				
				if(!$flag){
					$res[$i][1];
					$type[0] = strstr($res[$i][1],'(',true);
					$temp = strstr($res[$i][1],'(');
					$n_temp;
					
					for($j=1; $j<strlen($temp)-1; $j++){
						$n_temp  = $n_temp.mb_substr($temp,$j,1);
					}
					$type[1] = $n_temp;
					
					return $type;
					
				}
				else{
					return -1;
				}
			}
                        
                        public function getLastId($table,$id){
                                $r = $this->getRowDscLimit($table, array($id), $id, 0, 1);
                                return  $r[0][0]+ 1;
                            
                        }
			
	
			public function __destruct(){
			}
		}
               
        class indQuary extends query{  
				
			public function __construct($host = 'localhost', $user = 'websqflt_nasa',  $pass = '70LEk!YX73PU', $db = 'websqflt_nas'){
                            query::__construct($host,$user,$pass,$db);        
			}

                       public function printNewSelles($encptid){
                            $inp = new html();
                            $query = sprintf("SELECT idparty,name FROM (SELECT * FROM party_type WHERE type=1 OR type=2) as sel LEFT JOIN party USING(idparty) ORDER BY name");
                            $party = $this->getCustomizedSelectQuery($query, 2);
                            $query = sprintf("SELECT idproduct, name, unite, stock FROM (SELECT idunite, idproduct FROM product_details WHERE sell = 1) as PRO  JOIN product USING(idproduct) LEFT JOIN mesurment_unite USING(idunite) LEFT JOIN stock USING(idproduct);;");
                            $pro = $this->getCustomizedSelectQuery($query, 3);
                            
							echo "<script type='text/javascript' src='js/calculator.js'></script> ";
							echo "<br/>";
                            echo "<form action='editor.php' method = 'POST' class='embossed'>";
                            echo "<table class='centeraligned'>";
                                echo "<tr>";
                                    echo "<td colspan='3'>";
                                        echo "Client: ";
                                            $this->getDropDownRowArray($party, 0, 1, 'pt', $inp->value_pgd('pt'));
                                        echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date: &nbsp;&nbsp;";
                                           $inp->input_date('sd', date('Y-m-d'));
                                        echo "<br/>";
                                        echo "<br/>";
                                    echo "</td>";
                                echo "</tr>";
                                echo "<tr>";
                                    echo "<td>";
                                        echo "Product";
                                    echo "</td>";
                                    
                                    echo "<td>";
                                        echo "Quantity";
                                    echo "</td>";
                                    
                                    echo "<td>";
                                        echo "Rate";
                                    echo "</td>";
									
									echo "<td>";
                                        echo "Total";
                                    echo "</td>";
                                echo "</tr>";
								$num=$inp->value_pgd('num',5);
								echo "<input type = 'hidden' name = 'num' value='".$num."' />";
                                for($i=0; $i<$num; $i++){
                                    echo "<tr>";
                                        echo "<td>";
                                            $this->getDropDownRowArray($pro, 0, 1, 'pr_'.$i, $inp->value_pgd('pr_'.$i));
                                        echo "</td>";
                                        
                                        echo "<td>";
										    echo "<input type='number' step='any' name='pc_".$i."' value='".$inp->value_pgd('pc_'.$i)."' class='quantity' id='quantity_".$i."'/>";
                                        echo "</td>";
                                        
                                        echo "<td>";
										    echo "<input type='number' step='any' name='co_".$i."' value='".$inp->value_pgd('co_'.$i)."' class='rate' id='rate_".$i."'/>";
                                        echo "</td>";
										
										echo "<td class='total_td' id='total_td_".$i."' style='text-align:right;'></td>";
                                    echo "</tr>";
                                }
								echo "<tr>";
                                    echo "<th colspan='3'>";
                                       echo "Total :";
                                    echo "</th>";
									echo "<td id='grand_total' style='text-align:right;'>0</td>";
                                echo "</tr>";
								echo "<tr>";
                                    echo "<td colspan='4'>";
                                       echo "<br/><input type='submit' name='more_input' value='Add More'>";
                                    echo "</td>";
                                echo "</tr>";
                                echo "<tr>";
                                    echo "<td colspan='4'>";
                                        echo "<br/>";
										    echo "Transport cost : <input type='text' name='t' value='".$inp->value_pgd('t','0')."'>";
                                        echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
										    echo "Discount : <input type='number' step='any' id='discount' name='d' value='".$inp->value_pgd('d','0')."'>";
                                    echo "</td>";
                                echo "</tr>";
                                echo "<tr>";
                                    echo "<td colspan='4'>";
                                        echo "<br/>";
                                    echo "</td>";
                                echo "</tr>";
								echo "<tr>";
                                    echo "<th colspan='3'>";
										echo "Net Charges : ";
                                    echo "</th>";
                                    echo "<td colspan='1' id='netcharges' style='text-align:right;'>";
                                    echo "</td>";
                                echo "</tr>";
                                echo "<tr>";
                                    echo "<td colspan='3'>";
                                        echo "<br/><input type='submit' name='ab' value='Sell'/>";
										echo "<input type='hidden' name='editor' value='sells/new'/>";
                                        echo "<input type='hidden' name='e' value='".$encptid."'/>";
                                        echo "<input type='hidden' name='returnlink' value='index.php?page=sells&&sub=new&&e=".$encptid."'/>";
                                    echo "</td>";
                                echo "</tr>";
                            echo "</table>";
                            echo "</form>";
                        }

						public function newSelles($party, $date, $sel_info, $dis, $t){
                            mysql_query('START TRANSACTION');
                            $id = $this->getLastId('selles', 'idselles');
                            $flag = $this->InsQuery('selles', array('idselles','idparty','date'), array($id,$party,$date), array('d','d','s'));
							
                            foreach($sel_info as $info){
                                if($flag){
                                    $flag = $this->InsQuery('selles_details', array('idselles','idproduct','unite','rate'), array($id,$info[0],$info[1],$info[2]), array('d','d','d','f'));
                                    if($flag){
                                        $stock = $this->getCondRow('stock', array('stock'), 'idproduct', '=', $info[0]);
                                        
                                        if($stock[0][0] >= $info[1]){
                                            $query = sprintf("UPDATE stock SET stock = stock - %d WHERE idproduct = %d",$info[1],$info[0]);
                                            $flag = mysql_query($query);
                                            if(!$flag){
                                                mysql_query('ROLLBACK');
                                                return(-1);
                                            }
                                        }
                                        else{
                                            mysql_query('ROLLBACK');
                                            return(-2);
                                        }
                                    }
                                    else{
                                        break;
                                    }
                                }
                                else{
                                    break;
                                }
                            }
                            if($flag){
                                $flag = $this->InsQuery('selles_discount', array('idselles','discount'), array($id,$dis), array('d','d'));
                            }
							if($flag){
								$flag = $this->InsQuery('selles_delivery', array('idselles','cost'), array($id,$t), array('d','d'));
							}
							
							if($t>0){
                            $tid = $this->getLastId('transaction', 'id');
							if($flag){
								$flag = $this->InsQuery('transaction', array('id', 'date', 'type', 'ammount'), array($tid, $date, 1, -$t),  array('d','s','d','f'));
							
                            }
							if($flag){
                                $flag = $this->InsQuery('transaction_comment', array('id','comment'), array($tid, 'Transport cost'), array('d','s'));
							
                            }
                            
                            if($flag){
                                $flag = $this->InsQuery("party_payment", array("id","idparty"), array($tid,$party), array("d","d"));
							
                            }
							
							}						
                            if($flag){
                                mysql_query('COMMIT');
                                return $id;
                            }
                            else{
                                mysql_query('ROLLBACK');
                                return false;
                            }
                        }

                        public function printNewPurchase($encptid){
                            $inp = new html();
                            $query = sprintf("SELECT idparty,name FROM (SELECT * FROM party_type WHERE type = 0 OR type=2) as sel LEFT JOIN party USING(idparty) ORDER BY name");
                            $party = $this->getCustomizedSelectQuery($query, 2);
                            $query = sprintf("SELECT idproduct, name, unite, stock FROM (SELECT idunite, idproduct FROM product_details WHERE purchase = 1) as PRO  JOIN product USING(idproduct) LEFT JOIN mesurment_unite USING(idunite) LEFT JOIN stock USING(idproduct);;");
                            $pro = $this->getCustomizedSelectQuery($query, 3);
							echo "<script type='text/javascript' src='js/calculator.js'></script> ";
                            echo "<br/><form  action='editor.php' method = 'POST' class='embossed'>";
                            echo "<input type = 'hidden' name = 'num' value ='".count($pro)."' />";
                            echo "<table class='centeraligned'>";
                                echo "<tr>";
                                    echo "<td colspan='3'>"; 
									    echo "Date: ";
                                        $inp->input_date('sd', date('Y-m-d'));
                                        echo "&nbsp;&nbsp;&nbsp;Party : ";
                                            $this->getDropDownRowArray($party, 0, 1, 'pt', $inp->value_pgd('pt'));
                                        echo "&nbsp;&nbsp;&nbsp;";
										 echo "Voucher : <input type='text' name='res' value='".$inp->value_pgd('res')."'>";	
                                        echo "<br/>";	
                                        echo "<br/>";
                                    echo "</td>";
                                echo "</tr>";
                                echo "<tr>";
                                    echo "<td>";
                                        echo "Product";
                                    echo "</td>";
                                    
                                    echo "<td>";
                                        echo "Quantity";
                                    echo "</td>";
                                    
                                    echo "<td>";
                                        echo "Rate";
                                    echo "</td>";
									echo "<td>";
                                        echo "Total";
                                    echo "</td>";
                                echo "</tr>";
								$num=$inp->value_pgd('num',5);
								echo "<input type = 'hidden' name = 'num' value='".$num."' />";
                                for($i=0; $i<$num; $i++){
                                    echo "<tr>";
                                        echo "<td>";
                                                $this->getDropDownRowArray($pro, 0, 1, 'pr_'.$i, $inp->value_pgd('pr_'.$i));
                                         echo "</td>";
                                        
                                        echo "<td>";
                                                $inp->input_text(null, 'pc_'.$i, $inp->value_pgd('pc_'.$i), 'quantity', 'quantity_'.$i);
                                        echo "</td>";
                                        
                                        
                                        echo "<td>";
                                                $inp->input_text(null, 'co_'.$i, $inp->value_pgd('co_'.$i), 'rate', 'rate_'.$i);
                                        echo "</td>";
										
										
										echo "<td class='total_td' id='total_td_".$i."' style='text-align:right;'></td>";
                                    echo "</tr>";
                                }
								echo "<tr>";
                                    echo "<th colspan='3'>";
                                       echo "Total :";
                                    echo "</th>";
									echo "<td id='grand_total' style='text-align:right;'>0</td>";
                                echo "</tr>";
								echo "<tr>";
                                echo "<tr>";
                                    echo "<td colspan='4'>";
                                        echo "<br/><input type='submit' name='more_input' value='Add More'>";
										echo "<br/><br/>";
										    echo "Transport : <input type='text' name='t' value='".$inp->value_pgd('t','0')."'>";
                                        echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
										    echo "Discount : <input type='number' step='any' id='discount' name='d' value='".$inp->value_pgd('d','0')."'>";
                                    echo "</td>";
                                echo "</tr>";
                                echo "<tr>";
                                    echo "<td colspan='4'>";
										echo "<br/>";
                                    echo "</td>";
                                echo "</tr>";
								echo "<tr>";
                                    echo "<th colspan='3'>";
										echo "<big>Net Charges : </big>";
                                    echo "</th>";
                                    echo "<td colspan='1' id='netcharges' style='text-align:right;'>";
                                    echo "</td>";
                                echo "</tr>";
                                echo "<tr>";
                                    echo "<td colspan = '3'>";
                                        echo "<br/><input type='submit' name='ab' value='Purchase'/>";
										echo "<input type='hidden' name='editor' value='purchase/new'/>";
                                        echo "<input type='hidden' name='e' value='".$encptid."'/>";
                                        echo "<input type='hidden' name='returnlink' value='index.php?page=purchase&&sub=new&&e=".$encptid."'/>";
                                    echo "</td>";
                                echo "</tr>";
                            echo "</table>";
							echo "</form>";
                  }
                                                
                        public function newPurchase($party,$date,$sel_info,$dis, $voc, $t){
                            mysql_query('START TRANSACTION');
                            $id = $this->getLastId('purchase', 'idpurchase'); 
                            $flag = $this->InsQuery('purchase', array('idpurchase','idparty','date'), array($id,$party,$date), array('d','d','s'));
							if($flag){
								
							}
                            foreach($sel_info as $info){
                                if($flag){
                                    $flag = $this->InsQuery('purchase_details', array('idpurchase','idproduct','unite','rate'), array($id,$info[0],$info[1],$info[2]), array('d','d','d','f'));
                                    if($flag){
                                        
                                        $query = sprintf("UPDATE stock SET stock = stock + %d WHERE idproduct = %d",$info[1],$info[0]);
                                        $flag = mysql_query($query);
                                        if(!$flag){
                                            echo "Failed to update stock ";
                                        }
                                    }
                                    else{
                                        break;
                                    }
                                }
                                else{
                                    break;
                                }
                            }
							
                            if($flag){
                                $flag = $this->InsQuery('purchase_discount', array('idpurchase','discount'), array($id,$dis), array('d','d'));
                            }
                            if($flag){
                                $flag = $this->InsQuery('purchase_recipt', array('idpurchase','recipt'), array($id,$voc ), array('d','s'));
                            }
							if($flag){
								$flag = $this->InsQuery('purchase_delivery', array('idpurchase','cost'), array($id,$t), array('d','d'));
							}

                            $tid = $this->getLastId('transaction', 'id');
							if($flag ){
								$flag = $this->InsQuery('transaction', array('id', 'date', 'type', 'ammount'), array($tid, $date, 1, -$t),  array('d','s','d','f'));
							
                            }
							if($flag){
                                $flag = $this->InsQuery('transaction_comment', array('id','comment'), array($tid, 'Transport cost'), array('d','s'));
							
                            }
                            
                            if($flag){
                                $flag = $this->InsQuery("party_payment", array("id","idparty"), array($tid,$party), array("d","d"));
							
                            }
														
							
							
							
							
                            if($flag){
                                mysql_query('COMMIT');
                                return $id;
                                
                            }
                            else{
                                mysql_query('ROLLBACK');
                                return false;
                            }
                        }
						
                        public function addParty($name, $p1, $p2, $address, $type){
                            $id = $this->getLastId("party", "idparty");
                            mysql_query('START TRANSACTION');
                            $flag = $this->InsQuery('party', array('idparty','name'), array($id,$name), array('d','s'));
                            if($flag){
                                $flag = $this->InsQuery('party_adress', array('idparty','adress'), array($id,$address), array('d','s'));
                            }
                            if($flag){
                                if($flag && $p1 != ""){
                                    $flag = $this->InsQuery('party_phone', array('idparty','phone'), array($id, $p1), array('d','s'));
                                }
                                if($flag && $p2 != ""){
                                    $flag = $this->InsQuery('party_phone', array('idparty','phone'), array($id, $p2), array('d','s'));    
                                }
                                
                                if($flag){
                                    $flag = $this->InsQuery('party_type', array('idparty','type'), array($id, $type), array('d','s'));    
                                }
                            }
                            if($flag){
                                mysql_query('COMMIT');
                                return true;
                            }
                            else{
                                mysql_query('ROLLBACK');
                                return false;
                            }
                                
                        }
						
                        public function addNewTran($date, $am, $ttype, $tmedium, $c){
                            
                            $id = $this->getLastId('transaction', 'id');
                            
                            $query = sprintf("SELECT  SUM(ammount) FROM transaction GROUP BY type ORDER BY type;");
                            
                            $balance = $this->getCustomizedSelectQuery($query, 1);
                            
                            $cash = $balance[0][0];
                            
                            $bank = $balance[1][0];
                            
                            if($ttype == -1){
                                
                                if($tmedium == false){
                                    
                                    if($cash < $am ){
                                        echo "You dont have enough money (".$am.") in cash. You have ".$cash."<br/>";
                                        return false;
                                    }
                                }
                                else if($tmedium == true){
                                    if($bank < $am ){
                                        echo "You dont have enough money (".$am.") in cash. You have ".$bank."<br/>";
                                        return false;
                                    }
                                }
                            }
                            $am = $am * $ttype;
                            
                            mysql_query("START TRANSACTION");
                            $flag = $this->InsQuery('transaction', array('id', 'date', 'type', 'ammount'), array($id, $date, $tmedium, $am),  array('d','s','d','d'));
                            if($flag){
                                $flag = $this->InsQuery('transaction_comment', array('id','comment'), array($id,$c), array('d','s'));
                            }
                            
                            if($flag){
                                mysql_query('COMMIT');
                                return true;
                            }
                            else{
                                mysql_query('ROLLBACK');
                                return false;
                            }
                            
                            return true;
                            
                        }
                        
                        public function addTran($rel_id, $date, $am, $ttype, $tmedium, $c, $cat, $bank_info){
                            // rel_id
                            //cat = 1 party tran

                            $id = $this->getLastId('transaction', 'id');
                            
                            $query = sprintf("SELECT  SUM(ammount) FROM transaction GROUP BY type ORDER BY type;");
                            
                            $balance = $this->getCustomizedSelectQuery($query, 2);
                            
                            $cash = $balance[0][0];
                            
                            $bank = $balance[1][0];
                            
                            if($ttype == -1){
                                
                                if($tmedium == false){
                                    
                                    if($cash < $am ){
                                        echo "You dont have enough money (".$am.") in cash. You have ".$cash."<br/>";
                                        return false;
                                    }
                                }
                                else if($tmedium == true){
                                    if($bank < $am ){
                                        echo "You dont have enough money (".$am.") in bank. You have ".$bank."<br/>";
                                        return false;
                                    }
                                }
                            }
                            $am = $am * $ttype;
                            
                            mysql_query("START TRANSACTION");
                            $flag = $this->InsQuery('transaction', array('id', 'date', 'type', 'ammount'), array($id, $date, $tmedium, $am),  array('d','s','d','d'));
                            if($flag && $c != ""){
                                $flag = $this->InsQuery('transaction_comment', array('id','comment'), array($id, $c), array('d','s'));
                            }
                            
                            if($flag){
                                $flag = $this->InsQuery("party_payment", array("id","idparty"), array($id,$rel_id), array("d","d"));
                            }
                            if($tmedium == true && $flag){
                                $bank_info[0] = $id;
                                $flag = $this->InsQuery("cheque", array('id','bank', 'branch', 'date' , 'ac'), $bank_info, array('d','s','s','s','s'));
                            }
                            if($flag){
                                mysql_query('COMMIT');
                                return true;
                            }
                            else{
                                mysql_query('ROLLBACK');
                                return false;
                            }
                            
                            return true;
                            
                        
                            
                        }
                        
                        public function printAttendece(){
                            $query = sprintf("SELECT idstaff,name,post FROM staff WHERE status = 1 ORDER BY post ;");
                            
                            // $info got the neccesarry inforamtion about staff;
                            
                            $info = $this->getCustomizedSelectQuery($query, 3);
                            
                            // furtern customization is upto you
                            
                            echo "<br/>Attendence For : ";
                            $html = new html();
                            $d = date('Y-m-d');
                            $y = $d[0].$d[1].$d[2].$d[3];
                            $m = $d[5].$d[6];
                            $html->select_month('r_m',$m);
                            echo " of ";
                            $html->select_digit('r_y', 2011, 2021, $y , 1);
                            echo "<br/>";
                            
                            $i=0;
                            echo "<br/><table align='center' class='centeraligned'>";
                                echo "<tr>";
                                    echo "<th>Select</th>";
                                    echo "<th>Post</th>";
                                    echo "<th>Name</th>";
                                    echo "<th>Attended</th>";
                                    echo "<th>Leave</th>";
                                    echo "<th>Absent</th>";
                                    echo "<th>Overtime</th>";
                                echo "</tr>";
                            foreach($info as $staff){
                                echo "<tr>";
                                    echo "<td><input type = 'checkbox' name = 'staff_".$i."' value = '".$staff[0]."' /></td>" ;
                                echo "<td>".$staff[2].'</td><td>'.$staff[1].'</td>';
                                echo '<td>';
                                    if(isset($_POST['s_at'.$i]))
                                        $html->select_digit('s_at'.$i, 0, 31, $_POST['s_at'.$i], 1);
                                    else
                                        $html->select_digit('s_at'.$i, 0, 31, 0, 1);
                                echo '</td>';
                                
                                echo '<td>';
                                    if(isset($_POST['s_lv'.$i]))
                                        $html->select_digit('s_lv'.$i, 0, 31, $_POST['s_lv'.$i], 1);
                                    else
                                        $html->select_digit('s_lv'.$i, 0, 31, 0, 1);
                                echo '</td>';
                                
                                echo '<td>';
                                    if(isset($_POST['s_ab'.$i]))
                                        $html->select_digit('s_ab'.$i, 0, 31, $_POST['s_ab'.$i], 1);
                                    else
                                        $html->select_digit('s_ab'.$i, 0, 31, null, 1);
                                echo '</td>';
                                
                                echo '<td>';
                                    if(isset($_POST['s_ov'.$i]))
                                        $html->select_digit('s_ov'.$i, 0, 372, $_POST['s_ov'.$i], 1);
                                    else
                                        $html->select_digit('s_ov'.$i, 0, 372, 0, 1);
                                echo '</td>';
                                echo "</tr>";
                                $i++;
                            }
                            echo "</table>";
                            echo "<input type = 'hidden' name = 'num' value = '".COUNT($info)."' />";
                        }

                        public function printSallary(){
                            
                            $query = sprintf("SELECT idstaff,name,post,sallary FROM staff WHERE status = 1");
                            
                            $info = $this->getCustomizedSelectQuery($query, 4);
                            
                            $n = COUNT($info);

                            for($i = 0; $i < $n; $i++){
                                
                                $query = sprintf("SELECT sal_month, sal_year, sum(ammount) as ammount FROM staff_sallary WHERE sal_year = (SELECT MAX(sal_year) FROM staff_sallary WHERE idstaff = %d) AND idstaff = %d GROUP BY (sal_month) ORDER BY  sal_month DESC LIMIT 0,1",$info[$i][0],$info[$i][0]);
                                $fin_info = $this->getCustomizedSelectQuery($query, 3);
                                $p = count($info[$i]);
                                for($j=0; $j<3; $j++){
                                    $info[$i][$p + $j  ] = $fin_info[0][$j];
                                }
                                
                            }
                            
                            // furtern customization is upto you
                            
                            
                            
                            $html = new html();
                            $d = date('Y-m-d');
                            $y = $d[0].$d[1].$d[2].$d[3];
                            $m = $d[5].$d[6];
                            echo "<br/>";
                            
                            $i=0;
                            echo "<table align='center' class='centeraligned'>";
                                echo "<tr>";
                                    echo "<td>Select</td>";
                                    echo "<td>Post</td>";
                                    echo "<td>Name</td>";
                                    echo "<td>Sallary</td>";
                                    echo "<td>Last Paid</td>";
                                    echo "<td>Current</td>";
                                    echo "<td>ammount</td>";
                                echo "</tr>";
                                $i = 0;
                            foreach($info as $staff){
                                echo "<tr>";
                                    echo "<td><input type = 'checkbox' name = 'staff_".$i."' value = '".$staff[0]."' /></td>" ;
                                    
                                    echo "<td >".$staff[2].'</td>';
                                    if($m < $staff[4]){
                                        echo "<td ><font color = 'red' > ".$staff[1].' </font> </td> ';
                                    }
                                    else{
                                        echo "<td >".$staff[1].'</td>';
                                    }
                                echo '<td>';
                                    echo $staff[3];
                                echo '</td>';
                                
                                echo "<td align = 'center' >";
                                    echo $html->printMonth($staff[4]).'-'.$staff[5];
                                    echo "<br/>";
                                    echo $staff[6];
                                echo '</td>';
                                    
                                echo '<td>';
                                    $html->select_month('s_m'.$i,$m);
                                    $html->select_digit('s_y'.$i, 2011, 2021, $y , 1);
                                echo '</td>';
                                
                                
                                echo '<td>';
                                    $html->input_text(null, 's_a'.$i, isset($_POST['s_a'.$i]) ? $_POST['s_a'.$i] : $staff[3] );
                                echo '</td>';
                                
                                echo "</tr>";
                                $i++;
                            }
                            echo "</table>";
                            echo "<input type = 'hidden' name = 'num' value = '".COUNT($info)."' />";
                            
                        }
                        
                        public function InsAllAttendence($mon,$yer,$emp,$at,$lv,$ab,$ov,$j){
                            
                            $flag = true;
                            $rep_name = array ( 'rep_month','rep_year', 'idstaff', 'attended', 'rep_leave' ,'absent'  ,'overtime','sallary'  ,'hour');
                            $rep_flag = array('d','d','d','d','d','d','d','d','d');
                            
							$sal_hr  = null;
							$fault = array();
							$inp = new html();
							for($i=0; $i<COUNT($emp); $i++){
							     $q = sprintf("SELECT sallary,hour,name FROM staff WHERE idstaff = %d;",$emp[$i]);
								 $sal_hr[$i] = $this->getCustomizedSelectQuery( $q, 3);
								 
								 if($at[$i]+$lv[$i]+$ab[$i] != $inp->printMonthDays($mon,$yer)){
										array_push($fault,$sal_hr[$i][0][2]);
								 }
							}
							
							if(COUNT($fault)>0){
							    echo "<br/><h4 class='red'>Your input is wrong for the entries of";
								foreach($fault as $f){
									echo " ".$f.", ";
								}
								echo "<br/>because Attendence + Leave + Absent is not equal to ".$inp->printMonthDays($mon,$yer)."</h4>";
								return false;
							}
							else{
                            mysql_query('START TRANSACTION');
                            for($i=0; $i<$j; $i++){
                                if($flag){
                                    $flag = $this->InsQuery('staff_report', $rep_name ,  array($mon,$yer,$emp[$i],$at[$i],$lv[$i],$ab[$i],$ov[$i],$sal_hr[$i][0][0],$sal_hr[$i][0][1]), $rep_flag);
                                }
                                else{
                                    break;
                                }
                            }
                            if($flag){
                                mysql_query('COMMIT');
                                return true;
                            }
                            else{
                                mysql_query('ROLLBACK');
                                return false;
                                
                            }
							}
                        }
                        
                        public function addProduct($name,$mes_tpe, $pro_type, $price){
                            
                            $id = $this->getLastId("product", "idproduct");
                            mysql_query('START TRANSACTION');
                            $flag = $this->InsQuery('product', array('idproduct','name'), array($id,$name), array('d','s'));
                            if($flag){
                                if($pro_type == 0){
                                    // only selles
                                    $flag = $this->InsQuery('product_details', array('idproduct','idunite','sell','purchase'), array($id,$mes_tpe, 0, 1 ), array('d','d','d','d'));
                                }
                                else{
                                    // only purchase
                                    $flag = $this->InsQuery('product_details', array('idproduct','idunite','sell','purchase'), array($id,$mes_tpe, 1, 0 ), array('d','d','d','d'));
                                }
                                if($flag){
                                    $flag = $this->InsQuery('stock', array('idproduct'), array($id), array('d'));
                                }
                                if($flag){
                                    $flag = $this->InsQuery('price', array('idproduct','price'), array($id,$price), array('d','f'));
                                }
                            }
                            if($flag){
                                mysql_query('COMMIT');
                                return true;
                            }
                            else{
                                mysql_query('ROLLBACK');
                                return false;
                            }
                            
                        }
                                                                        
                        public function printPayment($id,$type,$cost){
						    $inp= new html();
						    echo "<br/><form method = 'POST' class='embossed'>";
                            echo "<br/>Date : ";
                            $inp->input_date('d', date('Y-m-d'));
                            
                            echo "<br/>";
                            echo "<br/>";
                            if($type == null){
                                $inp->input_raido('Giveing to ', 'p_t', -1, 0);
								echo "&nbsp&nbsp;&nbsp&nbsp;";
                                $inp->input_raido('Receiving from ', 'p_t', 1, 0);
                            }
                            else{
                                if($type == 1){
									echo "Receiving from <input type='hidden' name='p_t' value='1' >";
									$comment="Receiving from ";
                                }
								else{
									echo "Giveing to <input type='hidden' name='p_t' value='-1' >";
									$comment="Giveing to ";
								}
                            }
                            
                            if($id == null){
                                $party = $this->getCustomizedSelectQuery('SELECT * FROM party', 2);
                                $this->getDropDownRowArray($party, 0, 1, 'party', null);
                            }
                            else{
							    $party = $this->getCustomizedSelectQuery("SELECT name FROM party WHERE idparty=".$id, 1);
								echo "<b class='blue'>".$party[0][0]."</b>";
                                echo "<input type = 'hidden' name = 'party' value = '".$id."' />";
								$comment=$comment.$party[0][0];
                            }
                            echo "<br/>";
                            echo "<br/> In ";
					        echo "<input type = 'radio' name = 'p_m' value = '0'  onClick='hideallhidden();'checked/> Cash &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
							echo "<input type = 'radio' name = 'p_m' value = '1'  onClick='showallhidden();'/> Check";
                            echo " Of";
                            echo "<br/>";
							echo "<div  id='hidden'>";
                            $inp->input_text("Bank", 'c_bn', null);
                            $inp->input_text("Branch", 'c_br', null);
                            $inp->input_text("A/C", 'c_ac', null);
                            echo "Date";
                            $inp->input_date('c_d', date('Y-m-d'));
                            echo "<br/>";
							echo "</div>";
							echo "<br/>";
                            $inp->input_text("Taka", 'amnt', $cost);
                            echo "<br/>";
                            $inp->input_text("Comment", 'cmnt', $comment);
                            $inp->input_submit('ab', 'Save');
							echo "</form>";
                        }
                        
                        public function printEditSelles($vou){
                            
                            echo "<br/><form method = 'POST' class='embossed'>";
                            $query_pro = sprintf("SELECT idproduct, unite, rate, name FROM (SELECT idproduct,unite,rate FROM selles_details WHERE idselles = %d) as selles LEFT JOIN product USING (idproduct);",$vou);
                            $query_det = sprintf("SELECT name,date,discount FROM (SELECT * FROM selles s WHERE idselles = %d) as sell LEFT JOIN selles_discount USING (idselles) LEFT JOIN party USING (idparty);",$vou);
                            
                            $inp = new html();
                            
                            $inp->input_hidden('v', $vou);
                            
                            $sell_det = $this->getCustomizedSelectQuery($query_det, 3);
                            $sell_pro = $this->getCustomizedSelectQuery($query_pro, 4);
                            //$party = $this->getCustomizedSelectQuery('SELECT * FROM party', 2);
                            //$pro = $this->getCustomizedSelectQuery('SELECT * FROM product', 2);
                            
                            $n = COUNT($sell_pro);
							
                            $inp->input_hidden('num', $n);
                            echo "<table class='centeraligned' align='center'>";
                                echo "<tr>";
                                    echo "<td colspan = '3' >";
                                        echo "<br/>Was sold to : ";
                                        echo "<b class='blue'>".$sell_det[0][0]."</b>";
                                        echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;On date : ";
                                        echo "<b class='blue'>".$sell_det[0][1]."</b>";
                                        echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Voucher : ";
										echo "<b class='blue'>".$vou."</b><br/><br/>";
                                    echo "</td>";
                                echo "</tr>";
                                echo "<tr>";
                                    echo "<td>";
                                        echo "Product";
                                    echo "</td>";
                                    
                                    echo "<td>";
                                        echo "Quantity";
                                    echo "</td>";
                                    
                                    echo "<td>";
                                        echo "Cost";
                                    echo "</td>";
                                echo "</tr>";
                                for($i=0; $i<$n; $i++){
                                    echo "<tr>";
                                        echo "<td>";
                                                echo $sell_pro[$i][3];
                                                $inp->input_hidden('pr_'.$i, $sell_pro[$i][0]);                                               
                                        echo "</td>";
                                        
                                        echo "<td>";
                                            
                                            if(isset($_POST['pc_'.$i])){
                                                $inp->input_text(null, 'pc_'.$i, $_POST['pc_'.$i]);
                                                $inp->input_hidden('pr_pc_'.$i, $_POST['pr_pc_'.$i]);
                                                
                                            }
                                            else{
                                                $inp->input_text(null, 'pc_'.$i, $sell_pro[$i][1]);
                                                $inp->input_hidden('pr_pc_'.$i, $sell_pro[$i][1]);
                                                
                                            }
                                            
                                        echo "</td>";
                                        
                                        
                                        echo "<td>";
                                            if(isset($_POST['co_'.$i]))
                                                $inp->input_text(null, 'co_'.$i, $_POST['co_'.$i]);
                                            else
                                                $inp->input_text(null, 'co_'.$i, $sell_pro[$i][2]);
                                        echo "</td>";
                                    echo "</tr>";
                                }
                                echo "<tr>";
                                    echo "<td colspan = '3'><br/>";
                                        if(isset($_POST['d']))
                                            $inp->input_text('Discount', 'd', $_POST['d']);
                                        else
                                            $inp->input_text('Discount', 'd', $sell_det[0][2]);
                                    echo "</td>";
                                echo "</tr>";
							    echo "<tr>";
                                    echo "<td colspan = '3'>";
                                        $inp->input_submit('ab', 'save');
                                    echo "</td>";
                                echo "</tr>";
                            echo "</table>";
                            echo "</form>";
                        }
                        
                        public function sellesReturn($id,$pro,$d,$cost){
                            if($cost <= $d ){
                                echo "<br/>Discount cant be equal to cost";
                                return false;
                            }
                            mysql_query('START TRANSACTION');
                            
                            $flag = $this->updateColumn('selles_discount', array('discount'), array($d), array('d'), 'idselles', '=', $id);
                            
                            if(COUNT($pro)>0){
                                
                            
                            foreach($pro as $p){
                                if($flag){
                                    if(0 == $p[2] || $p[2] == null){
                                        $query = sprintf("DELETE FROM selles_details WHERE idselles = %d and idproduct = %d;",$id,$p[0]);
                                        $flag = mysql_query($query);
                                        if($flag){                                            
                                            $flag = $this->updateColumn('stock' , array('stock'), array('stock + '.$p[1]), array('d'), 'idproduct', '=', $p[0]);
                                        }
                                    }
                                    else if($p[1] > $p[2]){
                                        $flag = $this->updateColumn('stock' , array('stock'), array('stock + '.($p[1] - $p[2])), array('d'), 'idproduct', '=', $p[0]);
                                        if($flag){
                                            $query = sprintf("UPDATE selles_details SET unite = %d, rate = %f WHERE idselles = %d AND idproduct = %d",$p[2],$p[3],$id,$p[0]);                                            
                                            $flag = mysql_query($query);
                                        }
                                    }
                                    
                                }
                                else{
                                    unset($pro);
                                    mysql_query('ROLLBACK');
                                    return $flag;
                                    
                                }
                            }
                            }
                            unset($pro);
                            if($flag){
                                mysql_query('COMMIT');
                            }
                            else{
                                mysql_query('ROLLBACK');
                            }
                            return $flag;
                        }
                        
                        public function printReturnPur($vou){
                            
                            echo "<br/><form method = 'POST' class='embossed'>";
                            $query_pro = sprintf("SELECT idproduct, unite, rate, name FROM (SELECT idproduct,unite,rate FROM purchase_details WHERE idpurchase = %d) as purchase LEFT JOIN product USING (idproduct);",$vou);
                            $query_det = sprintf("SELECT name,date,discount FROM (SELECT * FROM purchase s WHERE idpurchase = %d) as purchase LEFT JOIN purchase_discount USING (idpurchase) LEFT JOIN party USING (idparty);",$vou);
                            
                            $inp = new html();
                            
                            $inp->input_hidden('v', $vou);
                            
                            $sell_det = $this->getCustomizedSelectQuery($query_det, 3);
                            $sell_pro = $this->getCustomizedSelectQuery($query_pro, 4);
                            //$party = $this->getCustomizedSelectQuery('SELECT * FROM party', 2);
                            //$pro = $this->getCustomizedSelectQuery('SELECT * FROM product', 2);
                            
                            $n = COUNT($sell_pro);
                            $inp->input_hidden('num', $n);
                         
                            echo "<table class='centeraligned' align='center'>";
                                echo "<tr>";
                                    echo "<td colspan = '3' >";
                                        echo "<br/>Was purchased from : ";
                                        echo "<b class='blue'>".$sell_det[0][0]."</b>";
                                        echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;On date : ";
                                        echo "<b class='blue'>".$sell_det[0][1]."</b>";
                                        echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Voucher : ";
										echo "<b class='blue'>".$vou."</b><br/><br/>";
                                    echo "</td>";
                                echo "</tr>";
                                echo "<tr>";
                                    echo "<td>";
                                        echo "Product";
                                    echo "</td>";
                                    
                                    echo "<td>";
                                        echo "Quantity";
                                    echo "</td>";
                                    
                                    echo "<td>";
                                        echo "Cost";
                                    echo "</td>";
                                echo "</tr>";
                                for($i=0; $i<$n; $i++){
                                    echo "<tr>";
                                        echo "<td>";
                                                echo $sell_pro[$i][3];
                                                $inp->input_hidden('pr_'.$i, $sell_pro[$i][0]);                                               
                                        echo "</td>";
                                        
                                        echo "<td>";
                                            
                                            if(isset($_POST['pc_'.$i])){
                                                $inp->input_text(null, 'pc_'.$i, $_POST['pc_'.$i]);
                                                $inp->input_hidden('pr_pc_'.$i, $_POST['pr_pc_'.$i]);
                                                
                                            }
                                            else{
                                                $inp->input_text(null, 'pc_'.$i, $sell_pro[$i][1]);
                                                $inp->input_hidden('pr_pc_'.$i, $sell_pro[$i][1]);
                                                
                                            }
                                            
                                        echo "</td>";
                                        
                                        
                                        echo "<td>";
                                            if(isset($_POST['co_'.$i]))
                                                $inp->input_text(null, 'co_'.$i, $_POST['co_'.$i]);
                                            else
                                                $inp->input_text(null, 'co_'.$i, $sell_pro[$i][2]);
                                        echo "</td>";
                                    echo "</tr>";
                                }
                                echo "<tr>";
                                    echo "<td colspan = '3'><br/>";
                                        if(isset($_POST['d']))
                                            $inp->input_text('Discount', 'd', $_POST['d']);
                                        else
                                            $inp->input_text('Discount', 'd', $sell_det[0][2]);
                                    echo "</td>";
                                echo "</tr>";
                                echo "<tr>";
                                    echo "<td colspan = '3'>";
                                        $inp->input_submit('ab', 'Save');
                                    echo "</td>";
                                echo "</tr>";
                            echo "</table>";
                            echo "</form>";
                        }
                        
                        public function purchaseReturn($id,$pro,$d,$cost){
                            if($cost <= $d ){
                                echo "Discount cant be equal to cost";
                                return false;
                            }
                            mysql_query('START TRANSACTION');
                            
                            $flag = $this->updateColumn('purchase_discount', array('discount'), array($d), array('d'), 'idpurchase', '=', $id);
                            
                            if(COUNT($pro)>0){
                                
                            
                            foreach($pro as $p){
                                if($flag){
                                    if(0 == $p[2] || $p[2] == null){
                                        $query = sprintf("DELETE FROM purchase_details WHERE idpurchase = %d and idproduct = %d;",$id,$p[0]);
                                        $flag = mysql_query($query);
                                        if($flag){                                            
                                            $flag = $this->updateColumn('stock' , array('stock'), array('stock + '.$p[1]), array('d'), 'idproduct', '=', $p[0]);
                                        }
                                    }
                                    else if($p[1] > $p[2]){
                                        $flag = $this->updateColumn('stock' , array('stock'), array('stock - '.($p[1] - $p[2])), array('d'), 'idproduct', '=', $p[0]);
                                        if($flag){
                                            $query = sprintf("UPDATE purchase_details SET unite = %d, rate = %f WHERE idpurchase = %d AND idproduct = %d",$p[2],$p[3],$id,$p[0]);                                            
                                            $flag = mysql_query($query);
                                        }
                                    }
                                    
                                }
                                else{
                                    unset($pro);
                                    mysql_query('ROLLBACK');
                                    return $flag;
                                    
                                }
                            }
                            }
                            unset($pro);
                            if($flag){
                                mysql_query('COMMIT');
                            }
                            else{
                                mysql_query('ROLLBACK');
                            }
                            return $flag;
                        }
                        
                        public function search_staff($s){
                            $query = "SELECT * FROM staff WHERE name LIKE '%$s%' ORDER BY name;";
                            return $this->getCustomizedSelectQuery($query, 5);
                        }
                        
                        public function search_party($s){
                            $query = "SELECT * FROM party LEFT JOIN party_adress USING (idparty) LEFT JOIN party_phone USING (idparty)  WHERE name LIKE '%$s%' OR adress LIKE '%$s%' OR phone LIKE '%$s%' ORDER BY name;";
                            return $this->getCustomizedSelectQuery($query, 5);
                        }
                        
                        public function search_product($s){
                            $query = "SELECT idproduct,name,stock,unite FROM product LEFT JOIN product_details USING (idproduct) LEFT JOIN mesurment_unite USING(idunite) LEFT JOIN stock USING(idproduct)  WHERE name LIKE '%$s%' ORDER BY name;";
                            return $this->getCustomizedSelectQuery($query, 4);
                        }
                        
                        public function search_sell($s){
                            $query1 = "SELECT idselles,name,date FROM (SELECT * FROM selles s WHERE idselles LIKE '%$s%') as s LEFT JOIN party USING (idparty);";
                            return $res1 =  $this->getCustomizedSelectQuery($query1, 3);
                            
                            
                        }
                        
                        public function search_pur($s){
                            $query2 = "SELECT idpurchase,recipt,name,date FROM (SELECT * FROM purchase_recipt WHERE recipt LIKE '%$s%') as p LEFT JOIN purchase USING (idpurchase) LEFT JOIN party USING(idparty);";
                            return $res1 =  $this->getCustomizedSelectQuery($query2, 4);
                            
                        }
                        
					    public function changecss($idstaff, $newcss){
						   $q=mysql_query("UPDATE  user SET css='$newcss' WHERE idstaff='$idstaff'");
						    if($q)
							   return 1;
							 else
							   return 0;
						}

				    public function changepass($idstaff, $newpass){
						   $q=mysql_query("UPDATE  user SET pass='$newpass' WHERE idstaff='$idstaff'");
						    if($q)
							   return 1;
							 else
							   return 0;
						}

				    public function get_particular_product_overview($id, $date1, $date2){
                        
                        $query = sprintf("SELECT name,sell, purchase FROM (SELECT * FROM product WHERE idproduct = %d) AS pro LEFT JOIN product_details USING(idproduct);",$id);
                        
                        $pro_type = $this->getCustomizedSelectQuery($query, 2);
                        
                        $query = null;
                        
						$pro_type[0][2];
                        if($pro_type[0][1]==1){
                            echo "<h2 class='blue'>".strtoupper($pro_type[0][0])." Sells Report</h2>";  
                            $query = sprintf("SELECT date, name,unite,rate FROM(SELECT * FROM selles WHERE date BETWEEN '%s' AND '%s') as selles JOIN (SELECT * FROM selles_details WHERE idproduct = %d) as selles_details USING(idselles) LEFT JOIN party USING (idparty) ORDER BY date DESC,idparty;",$date1,$date2,$id);
                        }
                        else{
                            echo "<h2 class='blue'>".strtoupper($pro_type[0][0])." Purchase Report</h2>";
                            $query = sprintf("SELECT date,name,unite,rate FROM(SELECT * FROM purchase WHERE date BETWEEN '%s' AND '%s') as purchase JOIN (SELECT * FROM purchase_details WHERE idproduct = %d) as purchase_details USING(idpurchase) LEFT JOIN party USING (idparty) ORDER BY date DESC,idparty;"  ,$date1,$date2,$id);                            
                        }
                        return $info = $this->getCustomizedSelectQuery($query, 4);
                    }
				    public function get_finished_product_overview($date1, $date2){
                        
                        $query = sprintf("SELECT date,pt.name,pr.name,sd.unite,mu.unite,sd.rate FROM (SELECT * FROM selles WHERE date BETWEEN '$date1' AND '$date2') as s LEFT JOIN party as pt USING (idparty) LEFT JOIN selles_details as sd USING(idselles) LEFT JOIN product as pr USING(idproduct) LEFT JOIN product_details as pd USING(idproduct) LEFT JOIN mesurment_unite as mu USING(idunite) ORDER BY date DESC,pt.name,pr.name ;");
                        
                        return $info = $this->getCustomizedSelectQuery($query, 6);
                    }
 
				    public function get_raw_product_overview($date1, $date2){
                        
                        $query = sprintf("SELECT date,pt.name,pr.name,sd.unite,mu.unite,sd.rate FROM (SELECT * FROM purchase WHERE date BETWEEN '$date1' AND '$date2') as s LEFT JOIN party as pt USING (idparty) LEFT JOIN purchase_details as sd USING(idpurchase) LEFT JOIN product as pr USING(idproduct) LEFT JOIN product_details as pd USING(idproduct) LEFT JOIN mesurment_unite as mu USING(idunite) ORDER BY date DESC,pt.name,pr.name ;");
                        
                        return $info = $this->getCustomizedSelectQuery($query, 6);
                    }
                    public function update_stock($id,$date,$st,$cur){
                          mysql_query('START TRANSACTION');
                          $flag = $this->InsQuery('product_input', array('date','idproduct','stock'), array($date,$id,$st), array('s','d','d'));
                        
                          if($flag){
                            $flag = $this->updateColumn('stock', array('stock'), array($cur+$st), array('d'), 'idproduct', '=', $id);
                          }
                          if($flag){
                              mysql_query('COMMIT');
                          }
                          else{
                              mysql_query('ROLLBACK');
                          }
                          return $flag;
                        }
						
						public function update_fac_stock($id,$date,$st,$cur){
                          mysql_query('START TRANSACTION');
                          $flag = $this->InsQuery('product_input', array('date','idproduct','stock','type'), array($date,$id,$st,1), array('s','d','d','d'));
                        
                          if($flag){
                            $flag = $this->updateColumn('stock', array('factory_stock'), array($cur+$st), array('d'), 'idproduct', '=', $id);
                          }
                          if($flag){
                              mysql_query('COMMIT');
                          }
                          else{
                              mysql_query('ROLLBACK');
                          }
                          return $flag;
                        }
					
						
                    public function delete_product_input($p,  $s){
                        
                        $id = $this->getCustomizedSelectQuery("SELECT idproduct FROM product_input WHERE idupdate = $p", 1);
                        
                        $query = sprintf("SELECT stock FROM stock WHERE idproduct = %d;",$id[0][0]);

                        $cs = $this->getCustomizedSelectQuery($query, 1);
                        
                        $flag = true;
                        $pid = $id[0][0];
                        if($cs[0][0]- $s >= 0 ){
                            $flag = true;                         
                        }
                        else{
                            $flag = false;
                            echo "<h3 class='red'>Not enough stock to perform this operation</h3><br/>";
                        }
                        
                        mysql_query('START TRANSACTION');
                        
                        
                        if($flag){
                            $query = sprintf("DELETE FROM product_input WHERE idupdate = %d", $p);
                            $flag = mysql_query($query);
                            
                        }
                        if($flag){
                            $flag = $this->updateColumn('stock', array('idproduct','stock'), array($id[0][0],$cs[0][0]-$s), array('d','d'), 'idproduct', '=', $pid);
                        }
                        if($flag){
                            mysql_query('COMMIT');
                        }
                        else{
                            mysql_query('ROLLBACK');
                        }
                        return $flag;
                    }
                    
                    public function printPartyFinOverview($id,$encptid,$name,$date1=null, $date2=null){
					        $inp=new html();
							if($date1&&$date2)
							{
								$query1 = sprintf("SELECT date, SUM(unite*rate) as sell,discount FROM (SELECT date, idselles FROM selles WHERE idparty = %d  AND date BETWEEN '%s' AND '%s') as selles LEFT JOIN selles_details USING (idselles)  LEFT JOIN selles_discount USING(idselles)  GROUP BY idselles;",$id,$date1,$date2);
								$query2 = sprintf("SELECT date, SUM(unite*rate) as purchase,discount FROM (SELECT date, idpurchase FROM purchase WHERE idparty = %d AND date BETWEEN '%s' AND '%s' ) as purchase LEFT JOIN purchase_details USING (idpurchase)  LEFT JOIN purchase_discount USING(idpurchase)  GROUP BY idpurchase;",$id,$date1,$date2);
								$query3 = sprintf("SELECT date, ammount, comment FROM (SELECT id FROM party_payment WHERE idparty = %d) as payment LEFT JOIN transaction USING (id) LEFT JOIN transaction_comment USING(id) WHERE date BETWEEN '%s' AND '%s';",$id,$date1,$date2);
							}
							else
							{
								$query1 = sprintf("SELECT date, SUM(unite*rate) as sell,discount FROM (SELECT date, idselles FROM selles WHERE idparty = %d) as selles LEFT JOIN selles_details USING (idselles)  LEFT JOIN selles_discount USING(idselles) GROUP BY idselles;",$id);
								$query2 = sprintf("SELECT date, SUM(unite*rate) as purchase,discount FROM (SELECT date, idpurchase FROM purchase WHERE idparty = %d) as purchase LEFT JOIN purchase_details USING (idpurchase)  LEFT JOIN purchase_discount USING(idpurchase) GROUP BY idpurchase;",$id);
								$query3 = sprintf("SELECT date, ammount, comment FROM (SELECT id FROM party_payment WHERE idparty = %d) as payment LEFT JOIN transaction USING (id) LEFT JOIN transaction_comment USING(id);",$id);
							}
                            $sell = $this->getCustomizedSelectQuery($query1, 3);
                            $pur = $this->getCustomizedSelectQuery($query2, 3);
                            $tran = $this->getCustomizedSelectQuery($query3, 3);
							
							$paid = 0;
                            $recived = 0;
							
                            echo "<br/><div class='embossed'>";
							echo "<img src='images/blank1by1.gif' width='600px' height='1px'/><br/>";
							echo "<a onclick='showit(0)'><h3>Transaction Report</h3></a>";
                            echo "<div  id='sud0'>";
                            if(COUNT($tran) > 0){
								if($date1&&$date2)
								{
									echo "<a href='print.php?e=".$encptid."&&page=party&&sub=individual_trans&&id=".$id."&&date1=".$date1."&&date2=".$date2."' class='button' target='_blank'><b>Print</b></a><br/>";
                                }
								else
								{
									echo "<a href='print.php?e=".$encptid."&&page=party&&sub=individual_trans&&id=".$id."' class='button' target='_blank'><b>Print</b></a><br/>";
                                }
								echo "<table align='center' class='rb'>";
                                    echo "<tr>";
                                        echo "<td>";
                                            echo "Date";
                                        echo "</td>";
                                    
                                        echo "<td>";
                                            echo " Paid to ".$name;
                                        echo "</td>";
                                    
                                        echo "<td>";
                                            echo " Recived from ".$name;
                                        echo "</td>";
                                        echo "<td>";
                                            echo "Comments";
                                        echo "</td>";
                                    echo "</tr>";
                                    foreach($tran as $s){
                                        echo "<tr>";
                                            echo "<td>";
                                                echo $inp->dateconvert($s[0]);
                                            echo "</td>";
                                            if($s[1]>0){
                                                echo "<td align = 'center' ></td>";
                                                echo "<td align = 'right' >".sprintf("%.2f",$s[1])."</td>";
                                                $recived += $s[1];
                                            }
                                            else{
                                                echo "<td align = 'right' >".sprintf("%.2f",-$s[1])."</td>";
                                                echo "<td align = 'center' ></td>";
                                                $paid += $s[1];
                                            }
											
                                            echo "<td>";
                                                echo $s[2];
                                            echo "</td>";
                                        echo "</tr>";
                                    }
                                    echo "<tr><td>Total </td> <td><b>".sprintf("%.2f",-$paid)."</b></td><td><b>".sprintf("%.2f",$recived)."</b  ></td><td> - </td></tr>";
                                echo "</table>";
                                
                            }
                            else{
                                if($date1&&$date2)
								{
									echo "<br/><h4 class='green'>You have no transactions with ".$name." between ".$inp->dateconvert($date1). " and ".$inp->dateconvert($date2)."</h4>";
								}
								else
								{
									echo "<br/><h4 class='green'>You have never done any transactions with  ".$name."</h4>";
								}
                            }
							echo "</div>";
							echo "</div>";
							
                            $bill_t = 0;
                            $bill_d = 0;
                            $total = 0;
							
                            echo "<br/><div class='embossed'>";
							echo "<img src='images/blank1by1.gif' width='600px' height='1px'/><br/>";
							echo "<a onclick='showit(1)'><h3>Sells Report</h3></a>";
                            echo "<div  id='sud1'>";
                            if(COUNT($sell) > 0){
								if($date1&&$date2)
								{
									echo "<a href='print.php?e=".$encptid."&&page=party&&sub=individual_sell&&id=".$id."&&date1=".$date1."&&date2=".$date2."' class='button' target='_blank'><b>Print</b></a><br/>";
                                }
								else
								{
									echo "<a href='print.php?e=".$encptid."&&page=party&&sub=individual_sell&&id=".$id."' class='button' target='_blank'><b>Print</b></a><br/>";
                                }
                                echo "<br/><table align='center' class='rb'>";
                                    echo "<tr>";
                                        echo "<td>";
                                            echo "Date";
                                        echo "</td>";
                                        echo "<td>";
                                            echo "Bill";
                                        echo "</td>";
                                    
                                        echo "<td>";
                                            echo "Discount";
                                        echo "</td>";
                                    echo "</tr>";
                                    foreach($sell as $s){
                                        echo "<tr>";
                                            echo "<td>".$inp->dateconvert($s[0])."</td>"."<td >".sprintf("%.2f",$s[1])."</td>"."<td>".$s[2]."</td>";
                                            $bill_t += $s[1];
                                            $bill_d += $s[2];
                                        echo "</tr>";
                                    }
                                    echo "<tr><td>Sum </td> <td>".sprintf("%.2f",$bill_t)."</td><td>".sprintf("%.2f",$bill_d)."</td></tr>";
                                    echo "<tr><td> Grand Total  </td> <td colspan = '2' > <b>".sprintf("%.2f",$bill_t-$bill_d)."</b></td></td></tr>";
                                    $total += ($bill_t-$bill_d);
                                echo "</table>";
                            }
                            else{
								if($date1&&$date2)
								{
									echo "<br/><h4 class='green'>You have not sold any item to ".$name." between ".$inp->dateconvert($date1). " and ".$inp->dateconvert($date2)."</h4>";
								}
								else
								{
									echo "<br/><h4 class='green'>You have never sold any item to ".$name."</h4>";
								}
                            }
							echo "</div>";
							echo "</div>";
            
                            $r_bill_t = 0;
                            $r_bill_d = 0;
                            
                            echo "<br/><div class='embossed'>";
							echo "<img src='images/blank1by1.gif' width='600px' height='1px'/><br/>";
							echo "<a onclick='showit(2)'><h3>Purchase Report</h3></a>";
                            echo "<div  id='sud2'>";
                            if(COUNT($pur) > 0){
								if($date1&&$date2)
								{
									echo "<a href='print.php?e=".$encptid."&&page=party&&sub=individual_purchase&&id=".$id."&&date1=".$date1."&&date2=".$date2."' class='button' target='_blank'><b>Print</b></a><br/>";
                                }
								else
								{
									echo "<a href='print.php?e=".$encptid."&&page=party&&sub=individual_purchase&&id=".$id."' class='button' target='_blank'><b>Print</b></a><br/>";
                                }
								echo "<table align='center' class='rb'>";
                                    echo "<tr>";
                                        echo "<td>";
                                            echo "Date";
                                        echo "</td>";
                                    
                                        echo "<td>";
                                            echo "Bill";
                                        echo "</td>";
                                    
                                        echo "<td>";
                                            echo "Discount";
                                        echo "</td>";
                                    echo "</tr>";
                                    foreach($pur as $s){
                                        echo "<tr>";
                                            echo "<td>".$inp->dateconvert($s[0])."</td>"."<td >".sprintf("%.2f",$s[1])."</td>"."<td>".$s[2]."</td>";
                                            $r_bill_t += $s[1];
                                            $r_bill_d += $s[2];
                                        echo "</tr>";
                                    }
                                    echo "<tr><td>Sum </td> <td>".sprintf("%.2f",$r_bill_t)."</td><td>".sprintf("%.2f",$r_bill_d)."</td></tr>";
                                    echo "<tr><td> Grand Total  </td> <td colspan = '2' > <b>".sprintf("%.2f",$r_bill_t-$r_bill_d)."</b></td></td></tr>";
								echo "</table>";
                            }
                            else{
								if($date1&&$date2)
								{
									echo "<br/><h4 class='green'>You have not purchased any item from ".$name." between ".$inp->dateconvert($date1). " and ".$inp->dateconvert($date2)."</h4>";
								}
								else
								{
									echo "<br/><h4 class='green'>You have never purchased any item from ".$name."</h4>";
								}
							}
							echo "</div>";
							echo "</div>";
							echo "<br/><img src='images/blank1by1.gif'  alt='Blank' onload='hideAllButZero(4)' class='rightflotingnoborder'>";
                    }

                    public function patry_adv_due($id){
                    
                        $query1 = sprintf("SELECT sum(ammount) FROM (SELECT * FROM party_payment WHERE idparty = %d) as pp LEFT JOIN transaction USING(id);",$id);
                        $query2 = sprintf("SELECT idparty,(cost-discount) FROM (SELECT idparty,SUM(unite*rate) AS cost FROM (SELECT * FROM purchase WHERE idparty = %d) as pur LEFT JOIN purchase_details USING(idpurchase)) as p LEFT JOIN  (SELECT idparty,sum(discount) as discount FROM (SELECT * FROM purchase WHERE idparty = %d) as p LEFT JOIN purchase_discount USING (idpurchase)) as dis  USING(idparty);",$id,$id);
                        $query3 = sprintf("SELECT idparty,(cost-discount) FROM (SELECT idparty,SUM(unite*rate) AS cost FROM (SELECT * FROM selles WHERE idparty = %d) as pur LEFT JOIN selles_details USING(idselles)) as s LEFT JOIN  (SELECT idparty,sum(discount) as discount FROM (SELECT * FROM selles WHERE idparty = %d) as p LEFT JOIN selles_discount USING (idselles)) as dis  USING(idparty)",$id,$id);
                        
                        //total transaction either plus or minus
                        $i1 = $this->getCustomizedSelectQuery($query1, 1);
                        //i2[0][1] total purchase 
                        $i2 = $this->getCustomizedSelectQuery($query2, 2);
                        //i3[0][1]total sell
                        $i3 = $this->getCustomizedSelectQuery($query3, 2);
                        return $i1[0][0] + $i2[0][1]- $i3[0][1];
                    }
                     
                    public function update_party($id,$name,$p1,$p2,$adrs,$type){
                        $flag = $this->updateColumn('party', array('name'), array($name), array('s'), 'idparty', '=', $id);
                        if($flag){
                            $flag = mysql_query("DELETE FROM party_phone WHERE idparty = $id");
                        }
                        
                        if($flag && $p1 != null ){
                            $flag = $this->InsQuery('party_phone', array('idparty','phone'), array($id,$p1), array('d','s'));
                        }
                        
                        if($flag && $p2 != null ){
                            $flag = $this->InsQuery('party_phone', array('idparty','phone'), array($id,$p2), array('d','s'));
                        }
                        
                        if($flag){
                            $flag = $this->updateColumn('party_adress', array('adress'), array($adrs), array('s'), 'idparty', '=', $id);
                        }
						
                        if($flag){
                            $flag = $this->updateColumn('party_type', array('type'), array($type), array('d'), 'idparty', '=', $id);
                        }
                        
                        if($flag){
                            mysql_query('COMMIT');
                        }
                        else{
                            mysql_query('ROLLBACK');
                        }
                        return $flag;
                    }
                    
                    public function addSallaryPay($date, $emp, $m, $y, $sal, $cmnt = 'Sallary'){

                            $id = $this->getLastId('transaction', 'id');
                            
                            $query = sprintf("SELECT  SUM(ammount) FROM transaction GROUP BY type ORDER BY type;");
                            $cols = array('id','idstaff', 'sal_month', 'sal_year');
                            
                            $balance = $this->getCustomizedSelectQuery($query, 1);
                            
                            $cash = $balance[0][0];
                            
                                    
                            if($cash < $sal ){
                                        echo "You dont have enough money (".$am.") in cash. You have ".$cash."<br/>";
                                        return false;
                            }
                            $am = -$sal;
                            mysql_query("START TRANSACTION");
                            $flag = $this->InsQuery('transaction', array('id', 'date', 'type', 'ammount'), array($id, $date, 0, $am),  array('d','s','d','d'));
                            if($flag){
                                $flag = $this->InsQuery('transaction_comment', array('id','comment'), array($id,$cmnt), array('d','s'));
                            }
                            
                            if($flag){
                                $flag = $this->InsQuery('staff_sallary', $cols, array($id,$emp,$m,$y), array('d','d','d','d',));        
                            }
                                                        
                            if($flag){
                                mysql_query('COMMIT');    
                                return true;
                            }
                            else{
                                echo 'something is wrong check your given data or contact with <a> unique webers </a>';
                                mysql_query('ROLLBACK');
                                return false;
                            }
                        }

                     public function addBonusPay($date, $emp, $m, $y, $bon, $cmnt = 'Bonus'){
                            
                            $cols = array('id','idstaff',  'month', 'year');
                            
                            $flag = true;
                            
                            
                            $id = $this->getLastId('transaction', 'id');
                            
                            $query = sprintf("SELECT  SUM(ammount) FROM transaction GROUP BY type ORDER BY type;");
                            
                            $balance = $this->getCustomizedSelectQuery($query, 1);
                            
                            $cash = $balance[0][0];
                            
                                    
                            if($cash < $sal ){
                                        echo "You dont have enough money (".$am.") in cash. You have ".$cash."<br/>";
                                        return false;
                            }
                            $am = -$bon;
                            
                            mysql_query("START TRANSACTION");
                            $flag = $this->InsQuery('transaction', array('id', 'date', 'type', 'ammount'), array($id, $date, 0, $am),  array('d','s','d','d'));
                            if($flag){
                                $flag = $this->InsQuery('transaction_comment', array('id','comment'), array($id,$cmnt), array('d','s'));
                            }
                            
                            
                            if($flag){
                                $flag = $this->InsQuery('staff_bonus', $cols, array($id,$emp,$m,$y), array('d','d','d','d'));
                            }
                                                        
                            if($flag){
                                mysql_query('COMMIT');    
                                return true;
                            }
                            else{
                                echo 'something is wrong check your given data or contact with <a> unique webers </a>';
                                mysql_query('ROLLBACK');
                                return false;
                            }

                        }
						
					public function purchase_delete($pur_id){
                            $query = sprintf("SELECT idproduct,stock-unite FROM (SELECT idproduct, unite FROM purchase_details p WHERE idpurchase = %d) as pur LEFT JOIN stock USING(idproduct);",$pur_id);
                            $info = $this->getCustomizedSelectQuery($query, 2);
                            $n = COUNT($info);
                            mysql_query('START TRANSACTION');
                            $flag = true;
                            for($i=0; $i<$n; $i++){
                                if($flag && $info[$i][1] >= 0){
                                    $flag = $this->updateColumn("stock", array('stock'), array($info[$i][1]), array('d'), 'idproduct', '=', $info[$i][0]);
                                }
                            }
                            $query = sprintf("DELETE FROM purchase WHERE idpurchase = %d",$pur_id);
                            $flag = mysql_query($query);
                            if($flag){
                                mysql_query('COMMIT');
                                return true;
                            }
                            mysql_query('ROLLBACK');
                            return false;
					}
					
					public function selles_delete($sel_id){
                            $query = sprintf("SELECT idproduct,stock+unite FROM (SELECT idproduct, unite FROM selles_details p WHERE idselles = %d) as sel LEFT JOIN stock USING(idproduct);",$pur_id);
                            $info = $this->getCustomizedSelectQuery($query, 2);
                            $n = COUNT($info);
                            mysql_query('START TRANSACTION');
                            $flag = true;
                            for($i=0; $i<$n; $i++){
                                if($flag && $info[$i][1] >= 0){
                                    $flag = $this->updateColumn("stock", array('stock'), array($info[$i][1]), array('d'), 'idproduct', '=', $info[$i][0]);
                                }
                            }
                            $query = sprintf("DELETE FROM selles WHERE idselles = %d",$sel_id);
                            $flag = mysql_query($query);
                            if($flag){
                                mysql_query('COMMIT');
                                return true;
                            }
                            mysql_query('ROLLBACK');
                            return false;
					}
					
                    public function editProduct($id,$name,$mt,$pt,$price){
                            
                            mysql_query('START TRANSACTION');
                            
                            $flag = $this->updateColumn('product', array('name'), array($name), array('s'), 'idproduct', '=', $id);
                            if($flag){
                                if($pt == 1){
                                    $sell = 0;
                                    $pur = 1;
                                }
                                else{
                                    $sell = 1;
                                    $pur = 0;
                                }
                                
                                $flag = $this->updateColumn('product_details', array('idunite','sell','purchase'), array($mt, $sell, $pur ), array('d','d','d'), 'idproduct', '=', $id);
                                
                                if($flag){
                                    $flag = $this->updateColumn('price', array('price'), array($price), array('f'), 'idproduct', '=', $id);
                                }
                            }
                            if($flag){
                                mysql_query('COMMIT');
                                return true;
                            }
                            else{
                                mysql_query('ROLLBACK');
                                return false;
                            }
                                                        
                        }
						
					public function getPrevBalance($date){
                            $query = sprintf("SELECT ammount FROM transaction WHERE date < '%s';",$date);
                            $bl = $this->getCustomizedSelectQuery($query, 1);
                            $n = COUNT($bl);
                            $t1 =  $t2 = 0;
                            for($i=0; $i<$n; $i++){
                                if($bl[$i][0] > 0){
                                    $t1 += $bl[$i][0];
                                }
                                else{
                                    $t2 += $bl[$i][0];
                                }
                            }
                            return ($t1+$t2);
                        }
										
					public function deleteTransaction($id){
					    $q=mysql_query("DELETE FROM transaction WHERE id='$id'");
						if($q)
						   return 1;
						else
						   return 0;
					}
                    
					public function current_stock($id){
						$query = sprintf("SELECT stock FROM stock WHERE idproduct = %d",$id);
						$res = $this->getCustomizedSelectQuery($query, 1);
						return $res[0][0];
					}
					
					public function delete_attendense($id, $mon, $yr){
						$query = sprintf("DELETE FROM staff_report WHERE idstaff = %d AND rep_month = %d AND rep_year = %d",$id,$mon,$yr);
						return mysql_query($query);
					}
					
					public function transfarProduct($product,$num, $type, $date){
							
                            
							if($type==2)
								$query1 = sprintf("UPDATE stock SET stock = stock + %d , factory_stock = factory_stock - %d WHERE idproduct = %d",$num,$num,$product);
							if($type==3)
								$query1 = sprintf("UPDATE stock SET stock = stock - %d , factory_stock = factory_stock + %d WHERE idproduct = %d",$num,$num,$product);
							mysql_query('START TRANSACTION');
							$flag = $this->excQuery($query1);
							if($flag)
								$flag = $this->InsQuery('product_input', array( 'date', 'idproduct', 'stock' ,'type'), array($date,$product,$num, $type),  array('s','d','f','d'));
                            
                            if($flag){
                                mysql_query('COMMIT');
								echo "<h2 class='green'>Stock Transfer Successful</h2><br/>";
                                return true;
                            }
                            mysql_query('ROLLBACK');
							echo "<h2 class='green'>Failed to Transfer Stock</h2><br/>";
                            return false;
							
							
					}
 			   }
?>
