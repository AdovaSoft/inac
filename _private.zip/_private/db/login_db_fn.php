<?php

  function login_check($userid,$userpass)
  {
    $encuserpass=md5(mysql_escape_string($userpass));
    $con = mysql_connect("localhost","websqflt_nasu","Yi&X&k6Eh0ZS");
    mysql_select_db("websqflt_nas");
	$userid = mysql_escape_string($userid);
	$qstring=sprintf("SELECT idstaff,pass,type,css FROM user LEFT JOIN staff USING(idstaff) WHERE pass='%s' AND name='%s'",$encuserpass,$userid);
    $q=mysql_query($qstring);   
    if(mysql_num_rows($q)>0)
    {
      mysql_close($con);
      return $q;
    }
    else
    {
      mysql_close($con);
      return 0;   
    }
  }
  
  function login_check_session($userid,$userpass)
  {
    $con = mysql_connect("localhost","websqflt_nasu","Yi&X&k6Eh0ZS");
    mysql_select_db("websqflt_nas");
	$qstring=sprintf("SELECT css FROM user LEFT JOIN staff USING(idstaff) WHERE pass='%s' AND name='%s'",$userpass,$userid);
    $q=mysql_query($qstring);   
    if(mysql_num_rows($q)>0)
    {
      mysql_close($con);
      return $q;
    }
    else
    {
      mysql_close($con);
      return 0;   
    }
  }
  
?>